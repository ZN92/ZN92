import { GoogleGenAI, Type } from "@google/genai";
import { VerificationResult, VerificationStatus, RiskLevel, RecommendedAction } from "../types";

export interface ForensicError extends Error {
  code: number;
  status?: string;
  category: 'QUOTA' | 'TIMEOUT' | 'SERVER' | 'NETWORK' | 'PARSE' | 'AUTH' | 'UNKNOWN';
  retryable: boolean;
  raw?: any;
}

const schema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      email: { type: Type.STRING },
      status: { type: Type.STRING, enum: Object.values(VerificationStatus) },
      riskLevel: { type: Type.STRING, enum: Object.values(RiskLevel) },
      confidenceScore: { type: Type.NUMBER },
      deliverabilityScore: { 
        type: Type.NUMBER, 
        description: "Forensic deliverability percentage from 1 to 100. Never 0." 
      },
      primaryRiskVector: { 
        type: Type.STRING, 
        description: "The main reason for risk or invalidity (e.g., DNS_FAULT, SMTP_BLOCK, SYNTAX_ERR, NONE)" 
      },
      scoreBreakdown: {
        type: Type.OBJECT,
        properties: {
          syntax: { type: Type.NUMBER },
          dns: { type: Type.NUMBER },
          smtp: { type: Type.NUMBER }
        },
        required: ['syntax', 'dns', 'smtp']
      },
      isDisposable: { type: Type.BOOLEAN },
      isRoleBased: { type: Type.BOOLEAN },
      isCatchAll: { type: Type.BOOLEAN },
      recommendedAction: { type: Type.STRING, enum: Object.values(RecommendedAction) },
      syntaxValid: { type: Type.BOOLEAN },
      auditLog: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            step: { type: Type.STRING },
            result: { type: Type.STRING },
            status: { type: Type.STRING, enum: ['success', 'warning', 'error'] }
          },
          required: ['step', 'result', 'status']
        }
      },
      domainAnalysis: {
        type: Type.OBJECT,
        properties: {
          mxLikelihood: { type: Type.STRING, enum: ['High', 'Low', 'None'] },
          typosquattingRisk: { type: Type.BOOLEAN },
          providerType: { type: Type.STRING, enum: ['Business', 'Free', 'Disposable', 'Educational', 'Unknown'] },
          dnsRecords: {
            type: Type.OBJECT,
            properties: {
              spf: { type: Type.STRING, enum: ['Configured', 'Missing', 'Invalid'] },
              dkim: { type: Type.STRING, enum: ['Found', 'Missing', 'Probable'] },
              dmarc: { type: Type.STRING, enum: ['Configured', 'Missing', 'Relaxed'] },
              bimi: { type: Type.BOOLEAN },
              mtaSts: { type: Type.BOOLEAN },
              mxServers: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ['spf', 'dkim', 'dmarc', 'bimi', 'mtaSts', 'mxServers']
          },
          smtpCheck: {
            type: Type.OBJECT,
            properties: {
              status: { type: Type.STRING, enum: ['Responsive', 'Timeout', 'Refused', 'Unknown'] },
              banner: { type: Type.STRING },
              supportsTLS: { type: Type.BOOLEAN },
              vrfySupported: { type: Type.BOOLEAN },
              greylistingDetected: { type: Type.BOOLEAN }
            },
            required: ['status', 'banner', 'supportsTLS', 'vrfySupported', 'greylistingDetected']
          }
        },
        required: ['mxLikelihood', 'typosquattingRisk', 'providerType', 'dnsRecords', 'smtpCheck']
      }
    },
    required: [
      'email', 'status', 'riskLevel', 'confidenceScore', 'deliverabilityScore', 'primaryRiskVector', 'scoreBreakdown', 
      'isDisposable', 'isRoleBased', 'isCatchAll', 
      'recommendedAction', 'syntaxValid', 'auditLog', 'domainAnalysis'
    ],
  },
};

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export async function verifyEmails(emails: string[]): Promise<VerificationResult[]> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const MAX_RETRIES = 3;
  let attempt = 0;

  while (attempt < MAX_RETRIES) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Perform a FORENSIC DELIVERABILITY AUDIT for: ${emails.join(", ")}.
        
        FORENSIC PROTOCOLS:
        1. ANALYZE INFRASTRUCTURE: Verify SPF/DKIM/DMARC alignment and SMTP banner metadata.
        2. CALCULATE HEALTH: Determine a precise deliverability score (1-100) based on domain stability and technical alignment.
        3. SYNTAX & ROLE AUDIT: Verify RFC compliance and role-based account detection.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: schema,
          thinkingConfig: { thinkingBudget: 512 }
        },
      });

      const textResponse = response.text;
      if (!textResponse) {
        const err = new Error("EMPTY_TELEMETRY_FAULT") as ForensicError;
        err.category = 'PARSE';
        err.retryable = true;
        throw err;
      }

      const parsedResults = JSON.parse(textResponse);
      if (!Array.isArray(parsedResults)) {
        const err = new Error("MALFORMED_TELEMETRY_PACKET") as ForensicError;
        err.category = 'PARSE';
        err.retryable = false;
        throw err;
      }
      
      return parsedResults;
    } catch (error: any) {
      attempt++;
      
      const errorStr = JSON.stringify(error).toLowerCase();
      const forensicErr = error as ForensicError;
      forensicErr.raw = error; // Store raw for deep inspection
      
      // Categorization Logic
      if (errorStr.includes("429") || errorStr.includes("quota") || errorStr.includes("resource_exhausted")) {
        forensicErr.category = 'QUOTA';
        forensicErr.code = 429;
        forensicErr.retryable = true;
      } else if (errorStr.includes("401") || errorStr.includes("403") || errorStr.includes("unauthenticated") || errorStr.includes("permission_denied") || errorStr.includes("api_key_invalid")) {
        forensicErr.category = 'AUTH';
        forensicErr.code = 401;
        forensicErr.retryable = false; // Auth errors shouldn't be retried automatically
      } else if (errorStr.includes("deadline") || errorStr.includes("timeout") || errorStr.includes("504")) {
        forensicErr.category = 'TIMEOUT';
        forensicErr.code = 504;
        forensicErr.retryable = true;
      } else if (errorStr.includes("500") || errorStr.includes("internal") || errorStr.includes("rpc failed") || errorStr.includes("entity was not found")) {
        forensicErr.category = 'SERVER';
        forensicErr.code = 500;
        forensicErr.retryable = true;
      } else if (errorStr.includes("fetch") || errorStr.includes("network") || errorStr.includes("offline")) {
        forensicErr.category = 'NETWORK';
        forensicErr.code = 0;
        forensicErr.retryable = true;
      } else {
        forensicErr.category = forensicErr.category || 'UNKNOWN';
        forensicErr.retryable = attempt < MAX_RETRIES;
      }
      
      if (forensicErr.retryable && attempt < MAX_RETRIES) {
        const baseDelay = forensicErr.category === 'QUOTA' ? 5000 : 1500;
        const backoffTime = Math.pow(2, attempt) * baseDelay + Math.random() * 1000;
        console.warn(`Neural Audit Failed (${forensicErr.category}). Attempt ${attempt}. Retrying in ${Math.round(backoffTime)}ms...`);
        await delay(backoffTime);
        continue;
      }
      
      throw forensicErr;
    }
  }
  
  const finalErr = new Error("MAX_RETRY_THRESHOLD_EXCEEDED") as ForensicError;
  finalErr.category = 'SERVER';
  finalErr.retryable = false;
  throw finalErr;
}
