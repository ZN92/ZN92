
import React, { useState } from 'react';
import { ICONS } from '../constants';
import { User, SubscriptionTier } from '../types';

interface AuthProps {
  onAuthenticate: (user: Partial<User>) => void;
}

export const Auth: React.FC<AuthProps> = ({ onAuthenticate }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState<'google' | 'linkedin' | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      onAuthenticate({
        email: formData.email,
        name: formData.name || formData.email.split('@')[0],
        tier: SubscriptionTier.FREE
      });
      setLoading(false);
    }, 1000);
  };

  const handleSocialLogin = (provider: 'google' | 'linkedin') => {
    setSocialLoading(provider);
    
    // Simulate OAuth handshake
    setTimeout(() => {
      const mockProfiles = {
        google: {
          email: 'sundar.p@google.com',
          name: 'Sundar Pichai',
          tier: SubscriptionTier.PRO,
          usageCount: 0,
          usageLimit: 5000
        },
        linkedin: {
          email: 'ryan.r@linkedin.com',
          name: 'Ryan Roslansky',
          tier: SubscriptionTier.PRO,
          usageCount: 0,
          usageLimit: 5000
        }
      };
      
      onAuthenticate(mockProfiles[provider]);
      setSocialLoading(null);
    }, 1500);
  };

  const handleDemoMode = () => {
    setLoading(true);
    setTimeout(() => {
      onAuthenticate({
        email: 'analyst@demo.io',
        name: 'Neural Analyst',
        tier: SubscriptionTier.PRO,
        usageCount: 42,
        usageLimit: 5000
      });
      setLoading(false);
    }, 800);
  };

  return (
    <div className="flex-grow flex items-center justify-center p-6 bg-slate-50/50 dark:bg-transparent">
      <div className="w-full max-w-md">
        <div className="bg-white dark:bg-slate-900 rounded-[40px] border border-slate-100 dark:border-slate-800 p-10 shadow-2xl shadow-slate-200/50 dark:shadow-none transition-colors duration-500">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-6">
              <div className="bg-indigo-600 dark:bg-indigo-500 p-4 rounded-3xl shadow-xl shadow-indigo-100 dark:shadow-none">
                <ICONS.Logo className="w-10 h-10 text-white" />
              </div>
            </div>
            <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tighter">
              {isLogin ? 'Welcome Back' : 'Create Account'}
            </h2>
            <p className="text-slate-400 dark:text-slate-500 text-sm font-medium mt-2">
              Access the neural verification terminal.
            </p>
          </div>

          {/* Social Protocols */}
          <div className="grid grid-cols-1 gap-3 mb-8">
            <button
              onClick={() => handleSocialLogin('google')}
              disabled={!!socialLoading || loading}
              className="flex items-center justify-center gap-3 w-full py-4 px-6 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all shadow-sm active:scale-[0.98] disabled:opacity-50"
            >
              {socialLoading === 'google' ? (
                <div className="w-5 h-5 border-2 border-slate-200 border-t-blue-500 rounded-full animate-spin"></div>
              ) : (
                <ICONS.Google className="w-5 h-5" />
              )}
              {socialLoading === 'google' ? 'Connecting to Google...' : 'Sign in with Google'}
            </button>
            
            <button
              onClick={() => handleSocialLogin('linkedin')}
              disabled={!!socialLoading || loading}
              className="flex items-center justify-center gap-3 w-full py-4 px-6 bg-[#0077b5] dark:bg-[#0077b5] text-white rounded-2xl font-bold hover:bg-[#00669c] transition-all shadow-sm active:scale-[0.98] disabled:opacity-50"
            >
              {socialLoading === 'linkedin' ? (
                <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
              ) : (
                <ICONS.LinkedIn className="w-5 h-5" />
              )}
              {socialLoading === 'linkedin' ? 'Syncing LinkedIn...' : 'Sign in with LinkedIn'}
            </button>
          </div>

          <div className="relative flex items-center justify-center mb-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-100 dark:border-slate-800"></div>
            </div>
            <span className="relative px-4 bg-white dark:bg-slate-900 text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">or continue with email</span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 ml-1">Full Name</label>
                <input
                  type="text"
                  required={!isLogin}
                  className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none font-bold text-sm dark:text-white transition-all"
                  placeholder="John Doe"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
              </div>
            )}
            
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 ml-1">Work Email</label>
              <input
                type="email"
                required
                className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none font-bold text-sm dark:text-white transition-all"
                placeholder="name@company.com"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 ml-1">Security Key</label>
              <input
                type="password"
                required
                className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none font-bold text-sm dark:text-white transition-all"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
              />
            </div>

            <div className="pt-4 space-y-4">
              <button
                type="submit"
                disabled={loading || !!socialLoading}
                className="w-full py-5 bg-indigo-600 dark:bg-indigo-500 text-white font-black rounded-2xl hover:bg-indigo-700 dark:hover:bg-indigo-600 transition-all shadow-xl shadow-indigo-100 dark:shadow-none disabled:bg-slate-200 dark:disabled:bg-slate-800"
              >
                {loading ? 'Initializing...' : (isLogin ? 'Launch Terminal' : 'Initialize Account')}
              </button>

              <button
                type="button"
                onClick={handleDemoMode}
                disabled={loading || !!socialLoading}
                className="w-full py-5 text-indigo-600 dark:text-indigo-400 font-black rounded-2xl bg-indigo-50 dark:bg-indigo-900/30 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-all"
              >
                Launch Demo Instance
              </button>
            </div>
          </form>

          <div className="mt-8 text-center">
            <button 
              onClick={() => setIsLogin(!isLogin)}
              className="text-xs font-bold text-slate-400 dark:text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
            >
              {isLogin ? "Don't have access? Create unit" : "Already have access? Portal entry"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
