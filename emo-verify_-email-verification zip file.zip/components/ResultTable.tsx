
import React from 'react';
import { VerificationResult, VerificationStatus } from '../types';
import { ICONS } from '../constants';

interface ResultTableProps {
  results: VerificationResult[];
  selectedEmails: Set<string>;
  onToggle: (email: string) => void;
  onDelete: (email: string) => void;
}

export const ResultTable: React.FC<ResultTableProps> = ({ 
  results, 
  selectedEmails, 
  onToggle, 
  onDelete 
}) => {
  const getStatusColor = (status: VerificationStatus) => {
    switch (status) {
      case VerificationStatus.VALID: return 'text-emerald-500 bg-emerald-500/10';
      case VerificationStatus.INVALID: return 'text-rose-500 bg-rose-500/10';
      case VerificationStatus.RISKY: return 'text-amber-500 bg-amber-500/10';
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-[32px] border border-slate-100 dark:border-slate-800 shadow-xl overflow-hidden animate-in fade-in duration-500">
      <div className="overflow-x-auto custom-scrollbar">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-950/50 border-b border-slate-100 dark:border-slate-800">
              <th className="p-5 w-14">
                <div className="flex items-center justify-center">
                  <div className="w-4 h-4 rounded border-2 border-slate-300 dark:border-slate-700" />
                </div>
              </th>
              <th className="p-5 text-[10px] font-black uppercase tracking-widest text-slate-400">Target Email</th>
              <th className="p-5 text-[10px] font-black uppercase tracking-widest text-slate-400">Status</th>
              <th className="p-5 text-[10px] font-black uppercase tracking-widest text-slate-400">Score</th>
              <th className="p-5 text-[10px] font-black uppercase tracking-widest text-slate-400">Risk Factor</th>
              <th className="p-5 text-[10px] font-black uppercase tracking-widest text-slate-400">Provider</th>
              <th className="p-5 text-[10px] font-black uppercase tracking-widest text-slate-400">Authentication</th>
              <th className="p-5 w-20"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50 dark:divide-slate-800/50">
            {results.map((res) => (
              <tr key={res.email} className="group hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                <td className="p-5 text-center">
                  <button 
                    onClick={() => onToggle(res.email)}
                    className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center transition-all ${
                      selectedEmails.has(res.email) 
                        ? 'bg-indigo-600 border-indigo-600 text-white' 
                        : 'border-slate-200 dark:border-slate-700 hover:border-indigo-400'
                    }`}
                  >
                    {selectedEmails.has(res.email) && <ICONS.CheckCircle className="w-3 h-3" strokeWidth={3} />}
                  </button>
                </td>
                <td className="p-5">
                  <div className="flex flex-col">
                    <span className="text-[12px] font-mono font-bold text-slate-900 dark:text-white truncate max-w-[200px]">
                      {res.email}
                    </span>
                    <span className="text-[8px] text-slate-400 uppercase tracking-widest mt-0.5">
                      SMTP: {res.domainAnalysis.smtpCheck.status}
                    </span>
                  </div>
                </td>
                <td className="p-5">
                  <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${getStatusColor(res.status)}`}>
                    {res.status}
                  </span>
                </td>
                <td className="p-5">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-1 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${res.deliverabilityScore > 80 ? 'bg-emerald-500' : res.deliverabilityScore > 40 ? 'bg-amber-500' : 'bg-rose-500'}`} 
                        style={{ width: `${res.deliverabilityScore}%` }} 
                      />
                    </div>
                    <span className="text-[10px] font-black dark:text-white">{Math.round(res.deliverabilityScore)}%</span>
                  </div>
                </td>
                <td className="p-5">
                  <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase truncate max-w-[120px]">
                    {res.primaryRiskVector === 'NONE' ? '-' : res.primaryRiskVector.replace('_', ' ')}
                  </span>
                </td>
                <td className="p-5">
                  <span className="text-[10px] font-bold dark:text-white uppercase tracking-tighter">
                    {res.domainAnalysis.providerType}
                  </span>
                </td>
                <td className="p-5">
                  <div className="flex gap-1.5">
                    {['spf', 'dkim', 'dmarc'].map((key) => {
                      const val = (res.domainAnalysis.dnsRecords as any)[key];
                      const active = val === 'Configured' || val === 'Found';
                      return (
                        <div 
                          key={key} 
                          className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase border ${
                            active 
                              ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500' 
                              : 'bg-rose-500/10 border-rose-500/20 text-rose-500'
                          }`}
                        >
                          {key}
                        </div>
                      );
                    })}
                  </div>
                </td>
                <td className="p-5 text-right">
                  <button 
                    onClick={() => onDelete(res.email)}
                    className="p-2 text-slate-300 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <ICONS.Trash className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {results.length === 0 && (
        <div className="p-20 text-center">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">No telemetry data matched current filters</span>
        </div>
      )}
    </div>
  );
};
