
import React, { useState } from 'react';
import { ICONS } from '../constants';

interface DocumentationProps {
  onBack: () => void;
}

export const Documentation: React.FC<DocumentationProps> = ({ onBack }) => {
  const [activeSection, setActiveSection] = useState('overview');

  const sections = [
    {
      id: 'overview',
      title: 'Neural Core Overview',
      content: (
        <div className="space-y-6">
          <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
            EMO Verify is a high-fidelity email intelligence platform powered by the <span className="text-indigo-600 font-black">Neural Engine v2.5</span>. It performs forensic deliverability audits by combining DNS analysis, SMTP handshake telemetry, and behavioral pattern recognition.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-6 bg-slate-50 dark:bg-slate-950 rounded-[28px] border border-slate-100 dark:border-slate-800">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-indigo-600 mb-2">Target Latency</h4>
              <p className="text-xl font-black dark:text-white">~1.2s / Node</p>
            </div>
            <div className="p-6 bg-slate-50 dark:bg-slate-950 rounded-[28px] border border-slate-100 dark:border-slate-800">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-emerald-600 mb-2">Audit Accuracy</h4>
              <p className="text-xl font-black dark:text-white">99.98% Confidence</p>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'deliverability',
      title: 'Deliverability Scoring',
      content: (
        <div className="space-y-6">
          <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
            Every audit returns a <span className="font-bold text-slate-900 dark:text-white">Deliverability Percentage (1-100%)</span>. This score represents the mathematical likelihood of an email successfully landing in the primary inbox of the target recipient.
          </p>
          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 rounded-2xl border border-emerald-100 dark:border-emerald-900/30 bg-emerald-50/30 dark:bg-emerald-900/10">
              <span className="text-[10px] font-black text-emerald-600 bg-emerald-100 dark:bg-emerald-900/50 px-3 py-1 rounded-lg">80-100%</span>
              <p className="text-[11px] font-bold text-slate-600 dark:text-slate-300">HIGH HEALTH: Infrastructure is optimal. Recipient exists and is responsive.</p>
            </div>
            <div className="flex items-start gap-4 p-4 rounded-2xl border border-amber-100 dark:border-amber-900/30 bg-amber-50/30 dark:bg-amber-900/10">
              <span className="text-[10px] font-black text-amber-600 bg-amber-100 dark:bg-amber-900/50 px-3 py-1 rounded-lg">40-79%</span>
              <p className="text-[11px] font-bold text-slate-600 dark:text-slate-300">SUSPICIOUS: Potential grey-listing, missing SPF, or role-based account detected.</p>
            </div>
            <div className="flex items-start gap-4 p-4 rounded-2xl border border-rose-100 dark:border-rose-900/30 bg-rose-50/30 dark:bg-rose-900/10">
              <span className="text-[10px] font-black text-rose-600 bg-rose-100 dark:bg-rose-900/50 px-3 py-1 rounded-lg">1-39%</span>
              <p className="text-[11px] font-bold text-slate-600 dark:text-slate-300">CRITICAL: Mail server rejected handshake. High honeypot or spam trap likelihood.</p>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'dns',
      title: 'Domain Integrity Matrix',
      content: (
        <div className="space-y-6">
          <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
            The Neural Engine inspects the three pillars of email authentication to ensure the sender domain is not being spoofed and has high reputation.
          </p>
          <ul className="space-y-4">
            <li className="flex gap-4">
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-2 shrink-0" />
              <div>
                <h5 className="text-[10px] font-black uppercase text-slate-900 dark:text-white">SPF (Sender Policy Framework)</h5>
                <p className="text-[11px] text-slate-500">Validates authorized sending IP addresses for the domain.</p>
              </div>
            </li>
            <li className="flex gap-4">
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-2 shrink-0" />
              <div>
                <h5 className="text-[10px] font-black uppercase text-slate-900 dark:text-white">DKIM (DomainKeys Identified Mail)</h5>
                <p className="text-[11px] text-slate-500">Cryptographic signature ensuring email content has not been tampered with.</p>
              </div>
            </li>
            <li className="flex gap-4">
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-2 shrink-0" />
              <div>
                <h5 className="text-[10px] font-black uppercase text-slate-900 dark:text-white">DMARC (Domain-based Message Authentication)</h5>
                <p className="text-[11px] text-slate-500">Policy management for handling authentication failures (None, Quarantine, Reject).</p>
              </div>
            </li>
          </ul>
        </div>
      )
    },
    {
      id: 'api',
      title: 'Enterprise API Logic',
      content: (
        <div className="space-y-6">
          <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
            Integrate EMO Verify into your custom workflows using our standard JSON payload protocol.
          </p>
          <div className="bg-[#0F172A] rounded-3xl p-6 overflow-hidden">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="ml-4 text-[9px] font-black uppercase text-slate-500 tracking-[0.2em]">POST /v1/audit</span>
            </div>
            <pre className="text-[10px] font-mono text-emerald-400 overflow-x-auto">
{`{
  "targets": ["ceo@google.com"],
  "depth": "forensic",
  "sandbox": true
}`}
            </pre>
            <div className="h-px bg-white/5 my-4" />
            <pre className="text-[10px] font-mono text-indigo-400 overflow-x-auto">
{`// RESPONSE_PACKET
{
  "status": "success",
  "deliverability": 98.4,
  "handshake": "STABLE"
}`}
            </pre>
          </div>
        </div>
      )
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row gap-16">
        {/* Sidebar Navigation */}
        <div className="w-full md:w-80 shrink-0">
          <button onClick={onBack} className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-indigo-600 mb-12 hover:translate-x-1 transition-all">
            <ICONS.ChevronUp className="-rotate-90 w-4 h-4" />
            Console Terminal
          </button>
          
          <h2 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.4em] mb-10">System Manual</h2>
          <nav className="space-y-2">
            {sections.map(section => (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`w-full text-left p-5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  activeSection === section.id 
                    ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-200 dark:shadow-none translate-x-2' 
                    : 'text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {section.title}
              </button>
            ))}
          </nav>

          <div className="mt-20 p-8 bg-slate-900 rounded-[32px] text-white">
             <ICONS.Shield className="w-8 h-8 text-indigo-400 mb-4" />
             <h4 className="text-[10px] font-black uppercase tracking-widest mb-2">Support Node</h4>
             <p className="text-[9px] text-slate-500 font-bold leading-relaxed uppercase">
               Request a deep-dive technical consultant for enterprise deployment.
             </p>
             <button className="mt-6 text-[9px] font-black text-indigo-400 uppercase tracking-widest border-b border-indigo-400/30 pb-1">Open Ticket</button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-grow">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-3 px-6 py-2 bg-slate-100 dark:bg-slate-800 rounded-full border border-slate-200 dark:border-slate-700 mb-10">
               <ICONS.BookOpen className="w-4 h-4 text-indigo-600" />
               <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500">Protocol Documentation</span>
            </div>
            
            {sections.map(section => (
              section.id === activeSection && (
                <div key={section.id} className="animate-in fade-in slide-in-from-right-4 duration-500">
                  <h1 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tighter mb-10 uppercase leading-none">
                    {section.title}
                  </h1>
                  <div className="prose prose-slate dark:prose-invert max-w-none">
                    {section.content}
                  </div>
                </div>
              )
            ))}

            <div className="mt-24 pt-12 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
               <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                     <ICONS.User className="w-4 h-4 text-slate-400" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-black uppercase text-slate-900 dark:text-white">EMO Neural Analyst</span>
                    <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest">Last updated: Epoch 2025.04.12</span>
                  </div>
               </div>
               <div className="flex gap-4">
                  <button className="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl text-slate-400 hover:text-indigo-600 transition-all">
                    <ICONS.CheckCircle className="w-4 h-4" />
                  </button>
                  <button className="p-3 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-xl text-slate-400 hover:text-indigo-600 transition-all">
                    <ICONS.Copy className="w-4 h-4" />
                  </button>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
