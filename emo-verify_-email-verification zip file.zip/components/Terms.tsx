
import React from 'react';
import { ICONS } from '../constants';

interface TermsProps {
  onBack: () => void;
}

export const Terms: React.FC<TermsProps> = ({ onBack }) => {
  const sections = [
    {
      id: '01.0',
      title: 'Neural Audit Integrity',
      content: 'EMO Verify provides automated deliverability assessments based on real-time DNS and SMTP telemetry. While our Neural Engine v2.5 maintains a 99.98% accuracy rating, results are provided "as-is" for intelligence purposes. Users are responsible for final deliverability strategy.'
    },
    {
      id: '02.0',
      title: 'Data Sovereignty Protocol',
      content: 'In alignment with our Safety Protocols, EMO Verify maintains a zero-persistence registry. We do not store, sell, or aggregate recipient data beyond the active session or locally archived user reports. Data sovereignty remains with the account holder.'
    },
    {
      id: '03.0',
      title: 'Usage Constraints',
      content: 'Resource allocation is governed by the selected Node Tier. Users must not attempt to circumvent usage limits, reverse engineer the neural logic, or use the API for malicious harvesting of protected infrastructure data.'
    },
    {
      id: '04.0',
      title: 'SLA & Node Availability',
      content: 'Enterprise nodes are guaranteed 99.9% uptime. Scheduled maintenance cycles (Neural Syncs) will be communicated via the Console Terminal at least 24 hours in advance. Starter and Pro nodes operate on a shared resource pool.'
    },
    {
      id: '05.0',
      title: 'Liability Shield',
      content: 'EMO Labs is not liable for indirect, incidental, or consequential damages resulting from the use or inability to use the verification engine, including but not limited to loss of sender reputation or campaign ROI.'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 animate-in fade-in duration-700">
      <div className="mb-20">
        <button onClick={onBack} className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-indigo-600 mb-10 hover:translate-x-1 transition-all">
          <ICONS.ChevronUp className="-rotate-90 w-4 h-4" />
          Terminal Main
        </button>
        <h1 className="text-5xl md:text-7xl font-black text-slate-900 dark:text-white tracking-tighter leading-none mb-6 uppercase">Legal Protocols</h1>
        <p className="text-slate-500 dark:text-slate-400 font-bold text-sm tracking-wide uppercase">Service Agreement & Terms of Operation</p>
      </div>

      <div className="space-y-16">
        {sections.map((section) => (
          <div key={section.id} className="group flex flex-col md:flex-row gap-8 border-t border-slate-100 dark:border-slate-800 pt-10">
            <div className="md:w-32 shrink-0">
               <span className="text-[12px] font-mono font-black text-indigo-600 dark:text-indigo-400 tracking-widest">
                 {section.id}
               </span>
            </div>
            <div className="flex-grow">
               <h3 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight mb-4 transition-colors group-hover:text-indigo-600">
                 {section.title}
               </h3>
               <p className="text-slate-500 dark:text-slate-400 leading-relaxed font-medium text-sm">
                 {section.content}
               </p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-32 p-12 bg-slate-50 dark:bg-slate-900 rounded-[48px] border border-slate-100 dark:border-slate-800 text-center">
         <div className="w-12 h-12 bg-white dark:bg-slate-800 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-sm">
            <ICONS.Shield className="w-6 h-6 text-indigo-600" />
         </div>
         <h4 className="text-[11px] font-black uppercase tracking-[0.3em] text-slate-400 mb-4">Agreement Acknowledgement</h4>
         <p className="text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest max-w-sm mx-auto mb-8">
            By initializing a neural session or creating an account, you synchronize with these protocols.
         </p>
         <button 
           onClick={onBack}
           className="px-12 py-5 bg-slate-900 dark:bg-indigo-600 text-white text-[11px] font-black uppercase tracking-[0.4em] rounded-[24px] hover:bg-indigo-700 transition-all shadow-xl"
         >
           Accept & Return
         </button>
         
         <div className="mt-12 text-[9px] font-mono text-slate-300 dark:text-slate-600 uppercase tracking-widest">
            Last Synchronized: 2025.04.12 09:00:00 UTC
         </div>
      </div>
    </div>
  );
};
