
import React from 'react';
import { ICONS } from '../constants';

interface PrivacyProps {
  onBack: () => void;
  onNavigateContactDPO?: () => void;
}

export const Privacy: React.FC<PrivacyProps> = ({ onBack, onNavigateContactDPO }) => {
  const policies = [
    {
      id: 'P-01',
      title: 'Neural Data Acquisition',
      content: 'We exclusively collect data necessary for deliverability auditing. This includes target email addresses and metadata returned during SMTP/DNS handshakes. No content from your emails is ever accessed or acquired.'
    },
    {
      id: 'P-02',
      title: 'Processing Boundaries',
      content: 'All analysis is executed within transient neural sandboxes. Data is processed in-memory and is never persisted on long-term storage except when specifically requested by the user for historical archiving purposes.'
    },
    {
      id: 'P-03',
      title: 'Encryption Standards',
      content: 'Session data is protected by TLS 1.3 during transit. Archived audits are stored using AES-256 encryption at rest. Unique neural fingerprints ensure that your specific audit results are never visible to other network nodes.'
    },
    {
      id: 'P-04',
      title: 'Third-Party Interactivity',
      content: 'During verification, our engine interacts with global mail exchange (MX) servers. We do not share your user identity or account metadata with these third-party servers. All requests are proxied via anonymous neural nodes.'
    },
    {
      id: 'P-05',
      title: 'Retention Lifecycle',
      content: 'Non-archived session data is purged 60 minutes after the last active interaction. Locally archived reports remain under user control and can be permanently deleted via the Console Terminal at any time.'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 animate-in fade-in duration-700">
      <div className="mb-20">
        <button onClick={onBack} className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-indigo-600 mb-10 hover:translate-x-1 transition-all">
          <ICONS.ChevronUp className="-rotate-90 w-4 h-4" />
          System Home
        </button>
        <h1 className="text-5xl md:text-7xl font-black text-slate-900 dark:text-white tracking-tighter leading-none mb-6 uppercase">Privacy Framework</h1>
        <p className="text-slate-500 dark:text-slate-400 font-bold text-sm tracking-wide uppercase">Data Protection & Privacy Policy</p>
      </div>

      <div className="space-y-12">
        {policies.map((policy) => (
          <div key={policy.id} className="p-8 md:p-12 bg-white dark:bg-slate-900 rounded-[48px] border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-4 mb-6">
               <span className="text-[10px] font-mono font-black text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30 px-3 py-1 rounded-lg">
                 {policy.id}
               </span>
               <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight">
                 {policy.title}
               </h3>
            </div>
            <p className="text-slate-500 dark:text-slate-400 leading-relaxed font-medium text-sm md:text-base">
              {policy.content}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-32 p-16 bg-indigo-600 rounded-[64px] text-white text-center shadow-2xl shadow-indigo-200 dark:shadow-none relative overflow-hidden">
         {/* Decoration */}
         <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 blur-3xl" />
         <div className="absolute bottom-0 left-0 w-64 h-64 bg-black/10 rounded-full -ml-32 -mb-32 blur-3xl" />
         
         <div className="relative z-10">
            <ICONS.Shield className="w-16 h-16 text-white/90 mx-auto mb-8" />
            <h2 className="text-3xl font-black mb-6 uppercase tracking-tighter">Your Data, Your Sovereignty</h2>
            <p className="text-indigo-100 text-sm font-bold uppercase tracking-widest max-w-md mx-auto mb-12 leading-relaxed">
              EMO Verify is engineered on a foundation of radical transparency and zero-trust security.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button 
                onClick={onBack}
                className="px-10 py-5 bg-white text-indigo-600 text-[11px] font-black uppercase tracking-[0.4em] rounded-[24px] hover:bg-indigo-50 transition-all shadow-xl"
              >
                Return to Console
              </button>
              <button 
                onClick={onNavigateContactDPO}
                className="px-10 py-5 bg-indigo-500/50 text-white text-[11px] font-black uppercase tracking-[0.4em] rounded-[24px] hover:bg-indigo-500 transition-all border border-indigo-400/30"
              >
                Contact DPO
              </button>
            </div>
         </div>
      </div>
      
      <div className="mt-16 text-center">
         <span className="text-[9px] font-mono text-slate-400 dark:text-slate-600 uppercase tracking-widest">
            Privacy Compliance Version: 2025.A-R1
         </span>
      </div>
    </div>
  );
};
