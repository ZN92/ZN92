
import React, { useState, useEffect } from 'react';
import { ICONS } from '../constants';

interface ApiKey {
  id: string;
  name: string;
  key: string;
  status: 'active' | 'revoked';
  createdAt: number;
  usage: number;
}

interface ApiKeysProps {
  onBack: () => void;
}

export const ApiKeys: React.FC<ApiKeysProps> = ({ onBack }) => {
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [newKeyName, setNewKeyName] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('emo_api_keys');
    if (saved) {
      setKeys(JSON.parse(saved));
    } else {
      // Mock initial key
      const initial: ApiKey = {
        id: '1',
        name: 'Primary Node Console',
        key: 'ev_live_7x9a2b5c8d1e4f0g3h6i',
        status: 'active',
        createdAt: Date.now() - 86400000 * 5,
        usage: 1242
      };
      setKeys([initial]);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('emo_api_keys', JSON.stringify(keys));
  }, [keys]);

  const generateKey = () => {
    if (!newKeyName.trim()) return;
    const randomStr = Array.from({length: 20}, () => Math.random().toString(36)[2]).join('');
    const newKey: ApiKey = {
      id: Math.random().toString(36).substr(2, 9),
      name: newKeyName,
      key: `ev_live_${randomStr}`,
      status: 'active',
      createdAt: Date.now(),
      usage: 0
    };
    setKeys([newKey, ...keys]);
    setNewKeyName('');
    setShowModal(false);
    setFeedback("NEW TOKEN INITIALIZED");
  };

  const revokeKey = (id: string) => {
    setKeys(keys.map(k => k.id === id ? { ...k, status: 'revoked' as const } : k));
    setFeedback("TOKEN REVOKED");
  };

  const deleteKey = (id: string) => {
    setKeys(keys.filter(k => k.id !== id));
    setFeedback("TOKEN PURGED");
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setFeedback("TOKEN COPIED TO BUFFER");
  };

  useEffect(() => {
    if (feedback) {
      const timer = setTimeout(() => setFeedback(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [feedback]);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-20 animate-in fade-in duration-700">
      <div className="mb-16 flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div>
          <button onClick={onBack} className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-indigo-600 mb-8 hover:translate-x-1 transition-all">
            <ICONS.ChevronUp className="-rotate-90 w-4 h-4" />
            Return to Console
          </button>
          <h1 className="text-5xl font-black text-slate-900 dark:text-white tracking-tighter leading-none mb-4 uppercase">API Infrastructure</h1>
          <p className="text-slate-500 dark:text-slate-400 font-bold text-sm tracking-wide uppercase">Manage Automated Handshake Tokens</p>
        </div>
        
        <button 
          onClick={() => setShowModal(true)}
          className="px-10 py-5 bg-indigo-600 text-white text-[11px] font-black uppercase tracking-[0.4em] rounded-[24px] hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 dark:shadow-none flex items-center gap-3"
        >
          <ICONS.Plus className="w-4 h-4" />
          Generate Token
        </button>
      </div>

      <div className="space-y-6">
        {keys.length > 0 ? (
          keys.map((key) => (
            <div key={key.id} className={`group bg-white dark:bg-slate-900 rounded-[40px] border p-10 transition-all duration-500 ${key.status === 'revoked' ? 'border-rose-100 dark:border-rose-900/30 opacity-60' : 'border-slate-100 dark:border-slate-800 hover:shadow-2xl hover:border-indigo-100 dark:hover:border-indigo-900/50'}`}>
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-10">
                <div className="space-y-4">
                   <div className="flex items-center gap-4">
                      <div className={`w-2.5 h-2.5 rounded-full ${key.status === 'active' ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
                      <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight">{key.name}</h3>
                   </div>
                   <div className="relative group/key max-w-md">
                      <div className="bg-slate-50 dark:bg-slate-950 p-4 pr-16 rounded-2xl border border-slate-100 dark:border-slate-800 font-mono text-[11px] font-bold text-slate-600 dark:text-slate-300 break-all select-all">
                        {key.key}
                      </div>
                      <button 
                        onClick={() => copyToClipboard(key.key)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-indigo-600 transition-colors"
                        title="Copy to Clipboard"
                      >
                        <ICONS.Copy className="w-4 h-4" />
                      </button>
                   </div>
                </div>

                <div className="flex flex-wrap items-center gap-12 border-t lg:border-t-0 lg:border-l border-slate-100 dark:border-slate-800 pt-8 lg:pt-0 lg:pl-12">
                   <div>
                      <span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Utilization</span>
                      <span className="text-lg font-black dark:text-white">{key.usage.toLocaleString()} Pings</span>
                   </div>
                   <div>
                      <span className="block text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Initialized</span>
                      <span className="text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-widest">
                        {new Date(key.createdAt).toLocaleDateString()}
                      </span>
                   </div>
                   <div className="flex gap-2">
                      {key.status === 'active' ? (
                        <button 
                          onClick={() => revokeKey(key.id)}
                          className="px-6 py-3 bg-rose-50 dark:bg-rose-900/10 text-rose-600 dark:text-rose-400 text-[9px] font-black uppercase tracking-widest rounded-xl border border-rose-100 dark:border-rose-900/30 hover:bg-rose-600 hover:text-white transition-all"
                        >
                          Revoke
                        </button>
                      ) : (
                        <button 
                          onClick={() => deleteKey(key.id)}
                          className="p-3 text-slate-300 hover:text-rose-600 transition-colors"
                        >
                          <ICONS.Trash className="w-5 h-5" />
                        </button>
                      )}
                   </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="py-40 text-center text-slate-200 dark:text-slate-800">
             <ICONS.Lock className="w-24 h-24 mx-auto mb-8 opacity-20" />
             <span className="text-[12px] font-black uppercase tracking-[0.4em]">No Live Tokens Detected</span>
          </div>
        )}
      </div>

      {/* Generation Modal */}
      {showModal && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-6 backdrop-blur-md bg-slate-900/40 animate-in fade-in duration-300">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-[48px] p-12 border border-slate-100 dark:border-slate-800 shadow-2xl animate-in zoom-in-95 duration-300">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tighter mb-4">Initialize Token</h2>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-8">Assign a protocol name for this credential.</p>
            
            <input 
              type="text" 
              placeholder="e.g. Production AWS Node"
              value={newKeyName}
              onChange={(e) => setNewKeyName(e.target.value)}
              autoFocus
              className="w-full px-6 py-5 bg-slate-50 dark:bg-slate-950 border-2 border-slate-100 dark:border-slate-800 rounded-2xl outline-none focus:border-indigo-600 dark:focus:border-indigo-400 transition-all font-bold text-sm mb-8"
              onKeyDown={(e) => e.key === 'Enter' && generateKey()}
            />

            <div className="flex gap-4">
              <button 
                onClick={generateKey}
                disabled={!newKeyName.trim()}
                className="flex-grow py-5 bg-indigo-600 text-white text-[11px] font-black uppercase tracking-[0.3em] rounded-2xl hover:bg-indigo-700 transition-all disabled:opacity-20"
              >
                Create Token
              </button>
              <button 
                onClick={() => setShowModal(false)}
                className="px-8 py-5 text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors text-[11px] font-black uppercase tracking-widest"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {feedback && (
         <div className="fixed bottom-12 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[9px] font-black uppercase tracking-[0.3em] py-3 px-8 rounded-full shadow-2xl z-[600] animate-in slide-in-from-bottom-4">
            {feedback}
         </div>
      )}
    </div>
  );
};
