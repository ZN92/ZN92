
import React, { useState } from 'react';
import { ICONS } from '../constants';
import { BulkAudit, VerificationStatus } from '../types';

interface BulkHistoryProps {
  audits: BulkAudit[];
  onOpenReport: (id: string) => void;
  onDeleteAudit: (id: string) => void;
}

export const BulkHistory: React.FC<BulkHistoryProps> = ({ audits, onOpenReport, onDeleteAudit }) => {
  const [search, setSearch] = useState('');

  const filteredAudits = audits.filter(a => a.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 animate-in fade-in duration-700">
      <div className="mb-16 flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <h1 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tighter leading-none mb-4 uppercase">Audit Archives</h1>
          <p className="text-slate-500 dark:text-slate-400 font-bold text-sm tracking-wide uppercase">Historical Telemetry Repository</p>
        </div>
        
        <div className="relative w-full md:w-96">
          <ICONS.Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="SEARCH ARCHIVES..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-14 pr-6 py-4 bg-white dark:bg-slate-900 rounded-[24px] border border-slate-100 dark:border-slate-800 outline-none text-[11px] font-black uppercase tracking-widest dark:text-white focus:border-indigo-600 transition-all shadow-sm"
          />
        </div>
      </div>

      {filteredAudits.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {filteredAudits.map((audit) => (
            <div key={audit.id} className="group relative bg-white dark:bg-slate-900 rounded-[48px] border border-slate-100 dark:border-slate-800 p-10 hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 overflow-hidden">
               {/* Health Indicator Line */}
               <div className="absolute top-0 left-0 w-full h-2 flex">
                  <div className="bg-emerald-500 h-full transition-all" style={{ width: `${(audit.summary.valid / audit.totalNodes) * 100}%` }} />
                  <div className="bg-amber-500 h-full transition-all" style={{ width: `${(audit.summary.risky / audit.totalNodes) * 100}%` }} />
                  <div className="bg-rose-500 h-full transition-all" style={{ width: `${(audit.summary.invalid / audit.totalNodes) * 100}%` }} />
               </div>

               <div className="flex justify-between items-start mb-8">
                  <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-[24px] border border-slate-100 dark:border-slate-800">
                    <ICONS.History className="w-6 h-6 text-indigo-600" />
                  </div>
                  <button 
                    onClick={() => onDeleteAudit(audit.id)}
                    className="p-3 text-slate-300 dark:text-slate-600 hover:text-rose-600 opacity-0 group-hover:opacity-100 transition-all"
                  >
                    <ICONS.Trash className="w-4 h-4" />
                  </button>
               </div>

               <h3 className="text-xl font-black text-slate-900 dark:text-white mb-2 leading-tight uppercase truncate">{audit.name}</h3>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-8">
                  {new Date(audit.timestamp).toLocaleString()}
               </p>

               <div className="grid grid-cols-2 gap-4 mb-10">
                  <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-[24px] border border-slate-100 dark:border-slate-800">
                     <div className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Nodes</div>
                     <div className="text-lg font-black text-slate-900 dark:text-white">{audit.totalNodes}</div>
                  </div>
                  <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-[24px] border border-slate-100 dark:border-slate-800">
                     <div className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Health %</div>
                     <div className="text-lg font-black text-emerald-500">{Math.round((audit.summary.valid / audit.totalNodes) * 100)}%</div>
                  </div>
               </div>

               <button 
                onClick={() => onOpenReport(audit.id)}
                className="w-full py-5 bg-slate-900 dark:bg-indigo-600 text-white text-[11px] font-black uppercase tracking-[0.3em] rounded-[24px] hover:bg-indigo-600 dark:hover:bg-indigo-700 transition-all shadow-xl shadow-slate-200 dark:shadow-none"
               >
                 Launch Report
               </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-40 flex flex-col items-center justify-center text-slate-200 dark:text-slate-800">
           <ICONS.History className="w-24 h-24 mb-8 opacity-20" />
           <span className="text-[14px] font-black uppercase tracking-[0.4em]">No Encrypted Audits Found</span>
        </div>
      )}
    </div>
  );
};
