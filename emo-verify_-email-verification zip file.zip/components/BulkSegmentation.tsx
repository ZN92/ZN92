
import React, { useState, useMemo } from 'react';
import { ICONS } from '../constants';
import { BulkAudit, VerificationStatus, VerificationResult } from '../types';
import { ResultCard } from './ResultCard';

interface BulkSegmentationProps {
  audit: BulkAudit;
  onBack: () => void;
}

type SegmentPage = 'valid' | 'risky' | 'invalid';

export const BulkSegmentation: React.FC<BulkSegmentationProps> = ({ audit, onBack }) => {
  const [activeSegment, setActiveSegment] = useState<SegmentPage>('valid');
  const [searchTerm, setSearchTerm] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  const segments = {
    valid: audit.results.filter(r => r.status === VerificationStatus.VALID),
    risky: audit.results.filter(r => r.status === VerificationStatus.RISKY),
    invalid: audit.results.filter(r => r.status === VerificationStatus.INVALID)
  };

  const currentSegmentResults = useMemo(() => {
    return segments[activeSegment].filter(r => 
      r.email.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [activeSegment, searchTerm, audit.results]);

  const copyEmails = () => {
    const emails = segments[activeSegment].map(r => r.email).join('\n');
    navigator.clipboard.writeText(emails);
    setFeedback(`${segments[activeSegment].length} EMAILS COPIED`);
    setTimeout(() => setFeedback(null), 3000);
  };

  const getSegmentTheme = (seg: SegmentPage) => {
    switch (seg) {
      case 'valid': return { text: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-900/10', border: 'border-emerald-100 dark:border-emerald-900/30' };
      case 'risky': return { text: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-900/10', border: 'border-amber-100 dark:border-amber-900/30' };
      case 'invalid': return { text: 'text-rose-600 dark:text-rose-400', bg: 'bg-rose-50 dark:bg-rose-900/10', border: 'border-rose-100 dark:border-rose-900/30' };
    }
  };

  const currentTheme = getSegmentTheme(activeSegment);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 animate-in fade-in duration-700">
      <div className="flex flex-col lg:flex-row gap-12">
        
        {/* Sidebar Navigation */}
        <aside className="lg:w-80 shrink-0">
          <button onClick={onBack} className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-indigo-600 mb-12 hover:translate-x-1 transition-all">
            <ICONS.ChevronUp className="-rotate-90 w-4 h-4" />
            Audit Report
          </button>

          <h2 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.4em] mb-10">Result Segments</h2>
          
          <nav className="space-y-3">
            {[
              { id: 'valid', label: 'Healthy Nodes', icon: <ICONS.CheckCircle className="w-4 h-4" />, count: segments.valid.length, color: 'emerald' },
              { id: 'risky', label: 'Quarantine Vault', icon: <ICONS.AlertTriangle className="w-4 h-4" />, count: segments.risky.length, color: 'amber' },
              { id: 'invalid', label: 'Dead Sector', icon: <ICONS.Ban className="w-4 h-4" />, count: segments.invalid.length, color: 'rose' }
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveSegment(item.id as SegmentPage)}
                className={`w-full flex items-center justify-between p-6 rounded-[28px] border-2 transition-all duration-500 ${activeSegment === item.id 
                  ? 'bg-slate-900 dark:bg-indigo-600 border-slate-900 dark:border-indigo-600 text-white shadow-2xl' 
                  : 'bg-white dark:bg-slate-900 border-slate-50 dark:border-slate-800 text-slate-400 hover:border-slate-200 hover:text-slate-900'}`}
              >
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-xl ${activeSegment === item.id ? 'bg-white/10' : 'bg-slate-50 dark:bg-slate-800'}`}>
                    {item.icon}
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-widest">{item.label}</span>
                </div>
                <span className={`text-[11px] font-black ${activeSegment === item.id ? 'text-white' : 'text-slate-500'}`}>{item.count}</span>
              </button>
            ))}
          </nav>

          <div className="mt-12 p-8 bg-slate-50 dark:bg-slate-900 rounded-[40px] border border-slate-100 dark:border-slate-800">
             <div className="flex items-center gap-3 mb-4">
                <ICONS.Shield className="w-4 h-4 text-indigo-600" />
                <span className="text-[10px] font-black uppercase text-slate-900 dark:text-white">Segment Actions</span>
             </div>
             <div className="space-y-2">
                <button onClick={copyEmails} className="w-full text-left py-3 px-4 rounded-xl text-[9px] font-black uppercase tracking-widest text-slate-500 hover:bg-white dark:hover:bg-slate-800 hover:text-indigo-600 transition-all">Copy Segment Emails</button>
             </div>
          </div>
        </aside>

        {/* Dynamic Result Page */}
        <main className="flex-grow">
          <div className="bg-white dark:bg-slate-900 rounded-[56px] border border-slate-100 dark:border-slate-800 p-10 min-h-[800px] flex flex-col shadow-2xl shadow-slate-200/50 dark:shadow-none">
            
            <header className="mb-12">
               <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-10">
                  <div>
                    <h1 className="text-4xl font-black text-slate-900 dark:text-white uppercase tracking-tighter mb-2">
                      {activeSegment === 'valid' ? 'Verified Nodes' : activeSegment === 'risky' ? 'Quarantine Vault' : 'Dead Sector'}
                    </h1>
                    <div className="flex items-center gap-3">
                       <div className={`w-2 h-2 rounded-full animate-pulse ${activeSegment === 'valid' ? 'bg-emerald-500' : activeSegment === 'risky' ? 'bg-amber-500' : 'bg-rose-500'}`} />
                       <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                         Segment Integrity: {activeSegment === 'valid' ? 'NOMINAL' : activeSegment === 'risky' ? 'DEGRADED' : 'CRITICAL'}
                       </span>
                    </div>
                  </div>

                  <div className="relative w-full md:w-72">
                    <ICONS.Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="SEARCH SEGMENT..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-12 pr-6 py-4 bg-slate-50 dark:bg-slate-950 border border-transparent focus:border-indigo-600 outline-none rounded-2xl text-[10px] font-black uppercase tracking-widest dark:text-white transition-all"
                    />
                  </div>
               </div>

               <div className={`p-6 rounded-[32px] border ${currentTheme.bg} ${currentTheme.border} ${currentTheme.text} flex flex-wrap gap-8 items-center`}>
                  <div className="flex flex-col">
                    <span className="text-[8px] font-black uppercase opacity-60 mb-1">Total Payload</span>
                    <span className="text-xl font-black">{segments[activeSegment].length} Targets</span>
                  </div>
                  <div className="w-px h-8 bg-current opacity-10 hidden md:block" />
                  <div className="flex flex-col">
                    <span className="text-[8px] font-black uppercase opacity-60 mb-1">Global Weight</span>
                    <span className="text-xl font-black">{Math.round((segments[activeSegment].length / audit.results.length) * 100)}%</span>
                  </div>
                  <div className="ml-auto flex items-center gap-4">
                     <span className="text-[9px] font-black uppercase opacity-60">Ready for automated sync</span>
                     <ICONS.CheckCircle className="w-5 h-5 opacity-40" />
                  </div>
               </div>
            </header>

            <div className="flex-grow">
               {currentSegmentResults.length > 0 ? (
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {currentSegmentResults.map((res) => (
                      <ResultCard key={res.email} result={res} />
                    ))}
                 </div>
               ) : (
                 <div className="h-full flex flex-col items-center justify-center opacity-10 dark:opacity-5 py-40">
                    <ICONS.Logo className="w-32 h-32 mb-8" />
                    <span className="text-[14px] font-black uppercase tracking-[0.5em]">No Segment Data</span>
                 </div>
               )}
            </div>
          </div>
        </main>
      </div>

      {feedback && (
         <div className="fixed bottom-12 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[9px] font-black uppercase tracking-[0.3em] py-3 px-8 rounded-full shadow-2xl z-[600] animate-in slide-in-from-bottom-4">
            {feedback}
         </div>
      )}
    </div>
  );
};
