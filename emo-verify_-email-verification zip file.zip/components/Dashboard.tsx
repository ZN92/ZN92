import React, { useState, useRef, useMemo, useEffect } from 'react';
import { ICONS } from '../constants';
import { verifyEmails, ForensicError } from '../services/geminiService';
import { VerificationResult, VerificationStatus, User } from '../types';
import { ResultCard } from './ResultCard';
import { ResultTable } from './ResultTable';
import * as XLSX from 'xlsx';

const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const ITEMS_PER_PAGE = 10;

type VerificationMode = 'single' | 'bulk';
type ViewMode = 'cards' | 'sheet';

interface DashboardProps {
  user: User;
  onUpdateUsage: (increment: number) => void;
  onNavigateUpgrade: () => void;
}

/**
 * Enhanced Forensic Validation Logic
 * Catches edge cases beyond basic regex
 */
const validateEmailForensic = (email: string): { isValid: boolean; error?: string; resolution?: string } => {
  const target = email.trim();
  if (!target) return { isValid: false, error: "NULL_INPUT", resolution: "Target node cannot be empty." };
  
  if (target.length > 254) return { isValid: false, error: "PROTOCOL_OVERFLOW", resolution: "Email string exceeds maximum RFC length (254 chars)." };
  
  if (!target.includes('@')) return { isValid: false, error: "MISSING_SEPARATOR", resolution: "Node missing the '@' delimiter." };
  
  const parts = target.split('@');
  if (parts.length > 2) return { isValid: false, error: "AMBIGUOUS_DELIMITER", resolution: "Multiple '@' symbols detected. Infrastructure ambiguous." };
  
  const [local, domain] = parts;
  if (!local) return { isValid: false, error: "LOCAL_PART_EMPTY", resolution: "Recipient identifier missing before the '@'." };
  if (!domain) return { isValid: false, error: "DOMAIN_PART_EMPTY", resolution: "Domain identifier missing after the '@'." };

  // Character Forensics
  if (local.startsWith('.') || local.endsWith('.')) return { isValid: false, error: "DOT_PLACEMENT_FAULT", resolution: "Local part cannot start or end with a dot." };
  if (local.includes('..')) return { isValid: false, error: "CONSECUTIVE_DOTS", resolution: "Local part contains consecutive dots (RFC violation)." };
  
  if (!domain.includes('.')) return { isValid: false, error: "TLD_MISSING", resolution: "Domain node missing Top-Level Domain (e.g., .com, .io)." };
  if (domain.startsWith('.') || domain.endsWith('.')) return { isValid: false, error: "DOMAIN_DOT_FAULT", resolution: "Domain cannot start or end with a dot." };
  if (domain.includes('..')) return { isValid: false, error: "CONSECUTIVE_DOTS", resolution: "Domain contains consecutive dots." };
  
  // Check for invalid characters using a strict forensic regex
  const strictRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  if (!strictRegex.test(target)) return { isValid: false, error: "ILLEGAL_CHARSET", resolution: "Input contains characters not supported by standard SMTP protocols." };

  return { isValid: true };
};

export const Dashboard: React.FC<DashboardProps> = ({ 
  user,
  onUpdateUsage,
  onNavigateUpgrade
}) => {
  const [mode, setMode] = useState<VerificationMode>('bulk');
  const [viewMode, setViewMode] = useState<ViewMode>('cards');
  const [singleInput, setSingleInput] = useState('');
  const [bulkInput, setBulkInput] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [auditStep, setAuditStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [processedCount, setProcessedCount] = useState(0);
  const [sessionUsage, setSessionUsage] = useState(0);

  const [results, setResults] = useState<VerificationResult[]>([]);
  const [selectedEmails, setSelectedEmails] = useState<Set<string>>(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  const [error, setError] = useState<{ 
    message: string; 
    category: string; 
    resolution?: string; 
    traceId: string; 
    raw?: string; 
    actionLabel?: string; 
    onAction?: () => void;
    icon?: React.ReactNode;
  } | null>(null);
  const [showErrorTrace, setShowErrorTrace] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const [statusFilter, setStatusFilter] = useState<VerificationStatus | 'ALL'>('ALL');
  
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const resultsTopRef = useRef<HTMLDivElement>(null);
  const exportMenuRef = useRef<HTMLDivElement>(null);

  const [liveAnalysis, setLiveAnalysis] = useState<{ valid: string[]; malformed: string[] }>({ valid: [], malformed: [] });

  const auditStages = [
    "INITIALIZING NEURAL CLUSTER", 
    "PROXIED DNS SYNC ACTIVE", 
    "SMTP HANDSHAKE FORENSICS", 
    "FINALIZING AUDIT PROTOCOL"
  ];

  useEffect(() => {
    let interval: any;
    if (loading) {
      setAuditStep(0);
      interval = setInterval(() => setAuditStep(prev => (prev < 3 ? prev + 1 : prev)), 1200);
    } else {
      setAuditStep(0);
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [loading]);

  useEffect(() => {
    const segments = bulkInput.split(/([\n, ]+)/).filter(e => e.length > 0);
    const actualEmails = segments.filter(s => !/[\n, ]+/.test(s));
    setLiveAnalysis({ 
      valid: actualEmails.filter(email => validateEmailForensic(email).isValid), 
      malformed: actualEmails.filter(email => !validateEmailForensic(email).isValid) 
    });
  }, [bulkInput]);

  useEffect(() => {
    if (feedback) {
      const timer = setTimeout(() => setFeedback(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [feedback]);

  useEffect(() => {
    setCurrentPage(1);
  }, [statusFilter]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (exportMenuRef.current && !exportMenuRef.current.contains(event.target as Node)) {
        setShowExportMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    setShowErrorTrace(false);
    try {
      const extension = file.name.toLowerCase().split('.').pop();
      if (['xlsx', 'xls', 'csv'].includes(extension || '')) {
        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json<any>(firstSheet, { header: 1 });
        const extracted = rows.flat()
          .map(cell => String(cell).trim())
          .filter(cell => cell.includes('@') && validateEmailForensic(cell).isValid);
        
        if (extracted.length === 0) throw new Error("NO_NODES_FOUND");

        setBulkInput(prev => (prev ? prev + '\n' : '') + extracted.join('\n'));
        setMode('bulk');
        setFeedback(`INGESTED ${extracted.length} NODES FROM ${extension?.toUpperCase()}`);
      } else {
        const text = await file.text();
        setBulkInput(prev => (prev ? prev + '\n' : '') + text);
        setMode('bulk');
        setFeedback("RAW TEXT PROTOCOL LOADED");
      }
    } catch (err: any) {
      setError({ 
        category: "IMPORT_FAULT", 
        message: err.message === "NO_NODES_FOUND" ? "No valid email nodes detected in source." : "Failed to parse source infrastructure.",
        resolution: "Verify your source file uses standard UTF-8 encoding and contains valid email identifiers.",
        traceId: `ERR-IMP-${Math.floor(Math.random() * 99999)}`,
        raw: String(err),
        icon: <ICONS.XCircle className="w-10 h-10" />
      });
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleVerify = async () => {
    let targetEmails: string[] = [];

    if (mode === 'single') {
      const validation = validateEmailForensic(singleInput);
      if (!validation.isValid) {
        setError({
          category: `VALIDATION_FAULT`,
          message: `Malformed node structure: ${validation.error}`,
          resolution: validation.resolution,
          traceId: `VAL-${Math.floor(Math.random() * 99999)}`,
          icon: <ICONS.AlertTriangle className="w-10 h-10" />
        });
        return;
      }
      targetEmails = [singleInput.trim()];
    } else {
      targetEmails = liveAnalysis.valid;
    }

    if (targetEmails.length === 0) return;

    setError(null);
    setShowErrorTrace(false);
    setProgress(0);
    setProcessedCount(0);
    
    const remaining = user.usageLimit - user.usageCount;
    if (targetEmails.length > remaining) {
      setError({ 
        category: "CAPACITY_FAULT", 
        message: "Neural resource utilization limit exceeded.",
        resolution: `Your current node is saturated. You requested ${targetEmails.length} audits, but only have ${remaining} remaining capacity in this billing cycle.`,
        traceId: `ERR-CAP-${Math.floor(Math.random() * 99999)}`,
        actionLabel: "UPGRADE NODE",
        onAction: onNavigateUpgrade,
        icon: <ICONS.Shield className="w-10 h-10" />
      });
      return;
    }

    setLoading(true);
    setSelectedEmails(new Set());
    
    try {
      const CHUNK_SIZE = 5;
      let currentCount = 0;

      for (let i = 0; i < targetEmails.length; i += CHUNK_SIZE) {
        const chunk = targetEmails.slice(i, i + CHUNK_SIZE);
        const verificationResults = await verifyEmails(chunk);
        
        if (verificationResults && verificationResults.length > 0) {
          onUpdateUsage(verificationResults.length);
          setSessionUsage(prev => prev + verificationResults.length);
          setResults(prev => [...verificationResults, ...prev]);
        }
        
        currentCount += chunk.length;
        setProcessedCount(currentCount);
        const currentProgress = Math.round((currentCount / targetEmails.length) * 100);
        setProgress(currentProgress);
      }

      setFeedback(`AUDIT COMPLETE: ${targetEmails.length} NODES ANALYZED`);
      if (mode === 'single') setSingleInput('');
    } catch (err: any) {
      const fErr = err as ForensicError;
      // CRITICAL: Log full forensic trace for engineering review
      console.error('NEURAL_CORE_FAULT_RECOVERY_TRACE:', fErr.raw || fErr);
      
      let category = "NEURAL_AUDIT_ERROR";
      let message = "Neural Audit Error: Sequence interrupted.";
      let resolution = "The neural engine encountered an unexpected roadblock. Ensure stable connectivity and re-initiate the handshake sequence.";
      let icon = <ICONS.AlertTriangle className="w-10 h-10" />;
      let actionLabel: string | undefined = undefined;

      switch (fErr.category) {
        case 'QUOTA':
          category = "NEURAL_QUOTA_STALL";
          message = "Audit Engine Failure: Rate Limit Exceeded";
          resolution = "The upstream neural network is currently saturated. Please pause audits for 60 seconds to allow the token bucket to refresh. High batch volumes may trigger this frequently on standard tiers.";
          icon = <ICONS.Logo className="w-10 h-10 animate-pulse" />;
          actionLabel = "CHECK LIMITS";
          break;
        case 'AUTH':
          category = "CREDENTIAL_FAULT";
          message = "Audit Engine Failure: Handshake Denied";
          resolution = "The neural cluster rejected your access credentials. This typically indicates an expired API key or a missing project configuration. Re-authenticate via the terminal settings.";
          icon = <ICONS.Ban className="w-10 h-10 text-rose-500" />;
          actionLabel = "RE-AUTHENTICATE";
          break;
        case 'TIMEOUT':
          category = "LATENCY_THRESHOLD_BREACH";
          message = "Neural Audit Error: Handshake Timeout";
          resolution = "The target mail server failed to respond within our security window. This often happens with heavily protected enterprise servers. Try reducing batch size to increase reliability.";
          icon = <ICONS.History className="w-10 h-10" />;
          break;
        case 'NETWORK':
          category = "CONNECTIVITY_FAULT";
          message = "Audit Engine Failure: Network Desync";
          resolution = "Your terminal lost connection to the primary neural cluster. Verify your local internet uplink and DNS stability.";
          icon = <ICONS.Ban className="w-10 h-10" />;
          break;
        case 'PARSE':
          category = "TELEMETRY_MALFORMED";
          message = "Neural Audit Error: Intelligence Packet Corrupted";
          resolution = "The engine returned an unrecognizable telemetry packet. This is typically a temporary noise glitch in the neural sandbox. Re-initiating the audit should resolve the desync.";
          icon = <ICONS.XCircle className="w-10 h-10" />;
          break;
        case 'SERVER':
          category = "INTERNAL_ENGINE_FAULT";
          message = "Audit Engine Failure: Core System Exception";
          resolution = "The core engine encountered a major internal exception (500). Our systems have automatically logged this event for analysis. Please try again in 5 minutes.";
          icon = <ICONS.AlertTriangle className="w-10 h-10" />;
          break;
      }

      setError({ 
        category, 
        message, 
        resolution,
        traceId: `TRACE-${fErr.category || 'GEN'}-${Math.floor(Math.random() * 99999)}`,
        raw: JSON.stringify(fErr.raw || fErr, Object.getOwnPropertyNames(fErr.raw || fErr), 2),
        icon,
        actionLabel
      });
    } finally {
      setLoading(false);
    }
  };

  const usagePercent = Math.min(100, (user.usageCount / user.usageLimit) * 100);
  const remainingNodes = user.usageLimit - user.usageCount;
  const targetCount = mode === 'single' ? (singleInput ? 1 : 0) : liveAnalysis.valid.length;

  const filteredResults = useMemo(() => {
    return results.filter(r => {
      const matchesStatus = statusFilter === 'ALL' || r.status === statusFilter;
      return matchesStatus;
    });
  }, [results, statusFilter]);

  const totalPages = Math.ceil(filteredResults.length / ITEMS_PER_PAGE);
  const paginatedResults = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredResults.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredResults, currentPage]);

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
    resultsTopRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const deleteResult = (email: string) => {
    setResults(prev => prev.filter(r => r.email !== email));
  };

  const clearAllResults = () => {
    setResults([]);
    setSelectedEmails(new Set());
    setFeedback("AUDIT SESSION RESET SUCCESSFUL");
  };

  const clearSelectedResults = () => {
    if (selectedEmails.size === 0) return;
    const count = selectedEmails.size;
    setResults(prev => prev.filter(r => !selectedEmails.has(r.email)));
    setSelectedEmails(new Set());
    setFeedback(`PURGED ${count} SELECTED NODES`);
  };

  const clearInput = () => {
    if (mode === 'single') setSingleInput(''); else setBulkInput('');
    setError(null);
  };

  const toggleSelect = (email: string) => {
    setSelectedEmails(prev => {
      const next = new Set(prev);
      if (next.has(email)) next.delete(email); else next.add(email);
      return next;
    });
  };

  const handleXLSSync = async () => {
    if (filteredResults.length === 0) return;
    setIsSyncing(true);
    setShowExportMenu(false);
    try {
      await new Promise(resolve => setTimeout(resolve, 1200));
      const exportData = filteredResults.map(r => ({
        'Target Node': r.email,
        'Forensic Status': r.status,
        'Deliverability Health': `${r.deliverabilityScore}%`,
        'Confidence Factor': `${r.confidenceScore}%`,
        'Risk Severity': r.riskLevel,
        'Primary Signal': r.primaryRiskVector,
        'Domain Type': r.domainAnalysis.providerType,
        'SPF Alignment': r.domainAnalysis.dnsRecords.spf,
        'DKIM Marker': r.domainAnalysis.dnsRecords.dkim,
        'DMARC Policy': r.domainAnalysis.dnsRecords.dmarc,
        'SMTP Status': r.domainAnalysis.smtpCheck.status
      }));
      const ws = XLSX.utils.json_to_sheet(exportData);
      const tsv = XLSX.utils.sheet_to_csv(ws, { FS: '\t' });
      await navigator.clipboard.writeText(tsv);
      setFeedback("XLS SYNC: TSV BUFFER READY");
    } catch (err) {
      setFeedback("SYNC_FAULT: HANDSHAKE FAILED");
    } finally {
      setIsSyncing(false);
    }
  };

  const handleExportCSV = () => {
    if (filteredResults.length === 0) return;
    try {
      const exportData = filteredResults.map(r => ({
        'Target Node': r.email,
        'Forensic Status': r.status,
        'Deliverability Health': `${r.deliverabilityScore}%`,
        'Confidence Factor': `${r.confidenceScore}%`,
        'Risk Severity': r.riskLevel,
        'Primary Signal': r.primaryRiskVector,
        'Domain Type': r.domainAnalysis.providerType,
        'SPF Alignment': r.domainAnalysis.dnsRecords.spf,
        'DKIM Marker': r.domainAnalysis.dnsRecords.dkim,
        'DMARC Policy': r.domainAnalysis.dnsRecords.dmarc,
        'SMTP Status': r.domainAnalysis.smtpCheck.status
      }));
      const ws = XLSX.utils.json_to_sheet(exportData);
      const csv = XLSX.utils.sheet_to_csv(ws);
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `EMO_Audit_${new Date().getTime()}.csv`);
      link.click();
      setFeedback("CSV EXPORT SUCCESSFUL");
    } catch (err) {
      setFeedback("EXPORT_FAULT: CSV GENERATION FAILED");
    }
  };

  const filterOptions = ['ALL', 'Valid', 'Risky', 'Invalid'];
  const filterIndex = filterOptions.indexOf(statusFilter);

  // Real-time validation for single input
  const singleValidation = useMemo(() => validateEmailForensic(singleInput), [singleInput]);

  return (
    <div className="max-w-7xl mx-auto px-10 py-16 relative">
      <div className="mb-16 flex flex-col lg:flex-row items-start lg:items-end justify-between gap-12">
        <div>
           <h1 className="text-5xl lg:text-6xl font-black text-slate-900 dark:text-white tracking-tighter leading-none mb-6 uppercase">Neural Console</h1>
           <p className="text-slate-500 dark:text-slate-400 font-bold text-sm tracking-wide uppercase">Infrastructure Audit & Reliability Check</p>
        </div>
        
        <div className="w-full lg:w-[480px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-10 rounded-[48px] shadow-2xl shadow-slate-200/40 dark:shadow-none transition-all hover:border-indigo-500/50 group/monitor">
           <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                 <div className={`w-3.5 h-3.5 rounded-full ${loading ? 'bg-indigo-500 animate-pulse ring-4 ring-indigo-500/20' : (usagePercent > 90 ? 'bg-rose-500 shadow-lg shadow-rose-500/20' : 'bg-indigo-600')}`} />
                 <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Resource Telemetry</span>
              </div>
              <div className="flex items-baseline gap-1.5">
                <span className={`text-[13px] font-black ${usagePercent > 90 ? 'text-rose-500' : 'text-slate-900 dark:text-white'}`}>{remainingNodes.toLocaleString()}</span>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Nodes Avail.</span>
              </div>
           </div>
           
           <div className="grid grid-cols-3 gap-3 mb-8">
              <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 transition-all hover:bg-white dark:hover:bg-slate-900">
                 <span className="block text-[7px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Total Load</span>
                 <span className="text-md font-black dark:text-white">{user.usageLimit.toLocaleString()}</span>
              </div>
              <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 transition-all hover:bg-white dark:hover:bg-slate-900">
                 <span className="block text-[7px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Consumed</span>
                 <span className={`text-md font-black ${loading ? 'text-indigo-600 animate-pulse' : 'dark:text-white'}`}>{user.usageCount.toLocaleString()}</span>
              </div>
              <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 transition-all hover:bg-white dark:hover:bg-slate-900">
                 <span className="block text-[7px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Session</span>
                 <span className="text-md font-black text-indigo-500">{sessionUsage.toLocaleString()}</span>
              </div>
           </div>

           <div className="relative w-full h-5 bg-slate-50 dark:bg-slate-950 rounded-full overflow-hidden border border-slate-100 dark:border-slate-800 shadow-inner group/progress">
              <div 
                className={`h-full transition-all duration-1000 ease-out relative z-20 ${usagePercent > 90 ? 'bg-rose-500 shadow-[0_0_20px_rgba(244,63,94,0.5)]' : usagePercent > 70 ? 'bg-amber-500 shadow-[0_0_20px_rgba(245,158,11,0.5)]' : 'bg-gradient-to-r from-indigo-500 to-indigo-600 shadow-[0_0_20px_rgba(79,70,229,0.5)]'}`} 
                style={{ width: `${usagePercent}%` }} 
              />
              {!loading && targetCount > 0 && targetCount <= remainingNodes && (
                 <div 
                   className="absolute h-full bg-indigo-400/30 dark:bg-indigo-400/10 border-l border-indigo-400/50 transition-all duration-500 z-10 animate-pulse"
                   style={{ 
                     left: `${usagePercent}%`, 
                     width: `${(targetCount / user.usageLimit) * 100}%` 
                   }}
                 />
              )}
           </div>
           
           <div className="mt-8 flex items-center justify-between px-1">
              <div className="flex flex-col">
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Status Protocol</span>
                <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${usagePercent >= 100 ? 'text-rose-500' : 'text-emerald-500'}`}>
                  {usagePercent >= 100 ? 'QUOTA_STALL' : (loading ? 'SYNCING_USAGE...' : 'NODE_HEALTH_OPTIMAL')}
                </span>
              </div>
              {targetCount > 0 && !loading && (
                <div className="flex flex-col items-end">
                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Impact Forecast</span>
                  <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${targetCount > remainingNodes ? 'text-rose-500' : 'text-indigo-500'}`}>
                    {targetCount > remainingNodes ? 'CAPACITY_FAULT' : `-${targetCount} NODES`}
                  </span>
                </div>
              )}
           </div>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-12">
        <div className="col-span-12 space-y-12">
          {error && (
            <div className="bg-white dark:bg-slate-900 border-2 border-rose-500/30 rounded-[40px] shadow-2xl overflow-hidden transition-all duration-500">
               <div className="bg-rose-500/5 px-10 py-10 flex items-start gap-10">
                  <div className="p-6 bg-rose-500 text-white rounded-[28px] shadow-xl shrink-0">
                     {error.icon || <ICONS.AlertTriangle className="w-10 h-10" />}
                  </div>
                  <div className="flex-grow">
                     <div className="flex items-center justify-between mb-4">
                        <span className="text-[10px] font-black text-rose-600 uppercase tracking-[0.4em] px-4 py-1.5 bg-rose-100 rounded-lg">{error.category}</span>
                        <span className="text-[9px] font-mono text-slate-400 tracking-widest">{error.traceId}</span>
                     </div>
                     <h3 className="text-3xl font-black text-slate-900 dark:text-white mb-4 uppercase tracking-tight leading-none">{error.message}</h3>
                     <p className="text-[14px] font-bold text-slate-700 dark:text-slate-300 leading-relaxed bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-100 dark:border-slate-800">{error.resolution}</p>
                     
                     <div className="flex items-center gap-6 mt-6">
                        {error.actionLabel && (
                          <button onClick={error.onAction} className="px-8 py-3 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200">
                            {error.actionLabel}
                          </button>
                        )}
                        <button onClick={() => setShowErrorTrace(!showErrorTrace)} className="text-[10px] font-black text-slate-400 hover:text-indigo-600 uppercase tracking-widest flex items-center gap-3 transition-all">
                           {showErrorTrace ? 'Hide' : 'Reveal'} Technical Trace
                           <ICONS.ChevronDown className={`w-4 h-4 transition-transform ${showErrorTrace ? 'rotate-180' : ''}`} />
                        </button>
                     </div>

                     {showErrorTrace && error.raw && (
                        <div className="mt-6 p-6 bg-slate-950 rounded-[32px] border border-slate-800 text-[12px] font-mono text-rose-400 whitespace-pre-wrap break-all leading-relaxed custom-scrollbar max-h-96 overflow-y-auto">
                           <div className="text-[10px] font-black uppercase text-slate-600 mb-4 tracking-[0.2em] border-b border-slate-800 pb-2">Full Forensic Telemetry Trace</div>
                           {error.raw}
                        </div>
                     )}
                  </div>
                  <button onClick={() => setError(null)} className="text-slate-300 hover:text-slate-900 transition-colors"><ICONS.XCircle className="w-8 h-8" /></button>
               </div>
            </div>
          )}

          <div className="bg-white dark:bg-slate-900 rounded-[64px] border border-slate-200/60 dark:border-slate-800 p-12 relative overflow-hidden shadow-2xl">
            <div className="relative z-10">
              <div className="mb-12 flex items-center justify-between gap-10">
                <div className="bg-slate-100 dark:bg-slate-800 p-2 rounded-[28px] flex gap-2 w-[400px] border border-slate-200/50 dark:border-slate-700/50">
                  <button onClick={() => setMode('single')} className={`flex-1 py-4 rounded-[22px] text-[11px] font-black tracking-widest transition-all duration-300 ${mode === 'single' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-xl' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'}`}>SINGLE</button>
                  <button onClick={() => setMode('bulk')} className={`flex-1 py-4 rounded-[22px] text-[11px] font-black tracking-widest transition-all duration-300 ${mode === 'bulk' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-xl' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'}`}>BULK</button>
                </div>
                <div className="flex gap-4">
                  <button onClick={() => fileInputRef.current?.click()} className="p-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-indigo-600 rounded-2xl transition-all" title="Import Protocol"><ICONS.Import className="w-6 h-6" /></button>
                  <button onClick={clearInput} className="p-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-rose-600 rounded-2xl transition-all" title="Clear Buffer"><ICONS.Trash className="w-6 h-6" /></button>
                  <input type="file" ref={fileInputRef} onChange={handleFileImport} className="hidden" accept=".csv,.txt,.xlsx,.xls" />
                </div>
              </div>

              <div className="relative group/input animate-in fade-in zoom-in-95 duration-500">
                {mode === 'single' ? (
                  <div className="relative">
                    <input 
                      type="text" 
                      className={`w-full py-10 px-12 bg-slate-50 dark:bg-slate-950 rounded-[40px] outline-none font-mono text-2xl dark:text-white border-2 focus:bg-white dark:focus:bg-slate-900 shadow-inner transition-all ${
                        singleInput === '' ? 'border-transparent focus:border-indigo-500' :
                        singleValidation.isValid ? 'border-emerald-500/20 focus:border-emerald-500' : 'border-rose-500/20 focus:border-rose-500'
                      }`} 
                      placeholder="target@forensic.node" 
                      value={singleInput} 
                      onChange={(e) => setSingleInput(e.target.value)} 
                      onKeyDown={(e) => e.key === 'Enter' && handleVerify()} 
                    />
                    <div className="absolute right-8 top-1/2 -translate-y-1/2 flex items-center gap-6">
                        {singleInput && (
                          <div className={`flex items-center gap-2 px-4 py-2 rounded-xl border text-[10px] font-black uppercase tracking-widest animate-in slide-in-from-right-4 ${
                            singleValidation.isValid ? 'bg-emerald-50 dark:bg-emerald-900/10 border-emerald-200 dark:border-emerald-800 text-emerald-600' : 'bg-rose-50 dark:bg-rose-900/10 border-rose-200 dark:border-rose-800 text-rose-600'
                          }`}>
                            {singleValidation.isValid ? <ICONS.CheckCircle className="w-4 h-4" /> : <ICONS.XCircle className="w-4 h-4" />}
                            {singleValidation.isValid ? 'NOMINAL' : singleValidation.error}
                          </div>
                        )}
                        <ICONS.Logo className={`w-8 h-8 transition-colors ${singleInput === '' ? 'text-indigo-200 dark:text-slate-800' : singleValidation.isValid ? 'text-emerald-500' : 'text-rose-500'}`} />
                    </div>
                  </div>
                ) : (
                  <textarea 
                    className="w-full h-72 p-12 bg-slate-50 dark:bg-slate-950 rounded-[40px] outline-none font-mono text-lg dark:text-white border-2 border-transparent focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900 shadow-inner transition-all resize-none custom-scrollbar" 
                    placeholder="Ingest batch nodes or drop manifest here..." 
                    value={bulkInput} 
                    onChange={(e) => setBulkInput(e.target.value)} 
                  />
                )}
              </div>

              <button 
                onClick={handleVerify} 
                disabled={loading || (mode === 'single' ? !singleInput : !bulkInput) || usagePercent >= 100 || targetCount > remainingNodes} 
                className={`mt-10 w-full py-10 rounded-[48px] font-black uppercase tracking-[0.6em] text-sm flex items-center justify-center transition-all ${loading ? 'bg-slate-900 text-slate-500 cursor-not-allowed shadow-none' : (targetCount > remainingNodes ? 'bg-rose-500/10 text-rose-500 cursor-not-allowed border-2 border-rose-500/20' : (usagePercent >= 100 ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-2xl shadow-indigo-500/30'))}`}
              >
                {loading ? (
                  <div className="flex flex-col items-center w-full px-20">
                    <div className="flex justify-between w-full mb-4">
                      <span className="text-[11px] font-black text-indigo-400 animate-pulse uppercase tracking-widest">{auditStages[auditStep]}</span>
                      <span className="text-[11px] font-black text-white">{progress}%</span>
                    </div>
                    <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500 transition-all duration-500" style={{ width: `${progress}%` }}></div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-4">
                    <ICONS.Shield className="w-6 h-6" />
                    {targetCount > remainingNodes ? 'Insufficient Capacity' : (usagePercent >= 100 ? 'Quota Exceeded' : (mode === 'single' ? 'Scan Node' : `Verify ${targetCount} Nodes`))}
                  </div>
                )}
              </button>
            </div>
          </div>

          {results.length > 0 && (
            <div className="space-y-10" ref={resultsTopRef}>
               <div className="flex items-center gap-6 bg-white dark:bg-slate-900 p-8 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-sm relative z-[100]">
                  <div className="flex gap-4 items-center shrink-0 flex-grow">
                     <div className="flex bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl mr-2">
                        <button onClick={() => setViewMode('cards')} className={`p-3 rounded-xl transition-all ${viewMode === 'cards' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-sm' : 'text-slate-400'}`}><ICONS.Logo className="w-5 h-5" /></button>
                        <button onClick={() => setViewMode('sheet')} className={`p-3 rounded-xl transition-all ${viewMode === 'sheet' ? 'bg-white dark:bg-slate-700 text-indigo-600 shadow-sm' : 'text-slate-400'}`}><ICONS.List className="w-5 h-5" /></button>
                     </div>
                     
                     <div className="relative bg-slate-100 dark:bg-slate-800 p-1.5 rounded-[22px] flex items-center border border-slate-200/50 dark:border-slate-700/50">
                        <div 
                          className={`absolute top-1.5 bottom-1.5 rounded-2xl transition-all duration-500 ease-in-out shadow-lg ${
                            statusFilter === 'ALL' ? 'bg-indigo-600 shadow-indigo-500/20' :
                            statusFilter === 'Valid' ? 'bg-emerald-600 shadow-emerald-500/20' :
                            statusFilter === 'Risky' ? 'bg-amber-500 shadow-amber-500/20' :
                            'bg-rose-600 shadow-rose-500/20'
                          }`}
                          style={{ 
                            width: 'calc(25% - 3px)', 
                            left: `calc(${filterIndex * 25}% + 1.5px)` 
                          }}
                        />
                        {filterOptions.map(f => (
                           <button 
                             key={f} 
                             onClick={() => setStatusFilter(f as any)} 
                             className={`relative z-10 px-6 py-3.5 whitespace-nowrap rounded-2xl text-[10px] font-black uppercase tracking-widest transition-colors duration-300 w-28 text-center ${
                               statusFilter === f ? 'text-white' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
                             }`}
                           >
                             {f}
                           </button>
                        ))}
                     </div>
                  </div>
                  
                  <div className="w-px h-10 bg-slate-200 dark:bg-slate-800 mx-2" />
                  
                  <div className="relative flex items-center gap-4" ref={exportMenuRef}>
                     <div className="relative">
                        <button onClick={() => setShowExportMenu(!showExportMenu)} disabled={isSyncing} className={`group flex items-center gap-3 px-8 py-4 whitespace-nowrap rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${isSyncing ? 'bg-emerald-500 text-white shadow-xl animate-pulse' : 'bg-emerald-50 dark:bg-emerald-900/10 text-emerald-600 border border-emerald-100 dark:border-emerald-800 hover:bg-emerald-100'}`}>
                           {isSyncing ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <ICONS.Download className="w-4 h-4" />}
                           {isSyncing ? 'SYNCING...' : 'EXPORT'}
                        </button>
                        {showExportMenu && (
                          <div className="absolute top-full right-0 mt-5 w-80 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[40px] shadow-2xl p-6 z-[200]">
                             <button onClick={handleXLSSync} className="w-full flex items-center gap-5 p-5 rounded-3xl hover:bg-emerald-50 dark:hover:bg-emerald-900/10 transition-all text-left">
                                <div className="p-4 bg-emerald-100 dark:bg-emerald-600 rounded-2xl"><ICONS.Table className="w-6 h-6 text-emerald-600 dark:text-white" /></div>
                                <div><div className="text-[12px] font-black text-slate-900 dark:text-white">XLS Sheet Sync</div><div className="text-[9px] font-black text-emerald-600/70 uppercase tracking-widest">TSV Buffer</div></div>
                             </button>
                             <button onClick={handleExportCSV} className="w-full mt-2 flex items-center gap-5 p-5 rounded-3xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-all text-left">
                                <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-2xl"><ICONS.List className="w-6 h-6 text-blue-600 dark:text-blue-400" /></div>
                                <div><div className="text-[12px] font-black text-slate-900 dark:text-white">CSV Export</div><div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Standard File</div></div>
                             </button>
                          </div>
                        )}
                     </div>
                     {selectedEmails.size > 0 && (
                       <button onClick={clearSelectedResults} className="px-8 py-4 whitespace-nowrap rounded-2xl text-[10px] font-black uppercase tracking-widest bg-rose-600 text-white shadow-lg hover:bg-rose-700 transition-all animate-in zoom-in-95">PURGE SELECTED ({selectedEmails.size})</button>
                     )}
                     <button onClick={clearAllResults} className="px-8 py-4 whitespace-nowrap rounded-2xl text-[10px] font-black uppercase tracking-widest bg-rose-50 dark:bg-rose-900/10 text-rose-600 border border-rose-100 dark:border-rose-900/30 hover:bg-rose-100 transition-all">CLEAR ALL</button>
                  </div>
               </div>

               {viewMode === 'cards' ? (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 transition-opacity duration-500">
                   {paginatedResults.map((res) => (
                     <ResultCard key={res.email} result={res} selected={selectedEmails.has(res.email)} onToggle={toggleSelect} onDelete={() => deleteResult(res.email)} />
                   ))}
                 </div>
               ) : (
                 <ResultTable results={paginatedResults} selectedEmails={selectedEmails} onToggle={toggleSelect} onDelete={deleteResult} />
               )}

               {totalPages > 1 && (
                 <div className="mt-16 flex items-center justify-center gap-4">
                   <button onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} className="px-10 py-5 rounded-[28px] bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-[11px] font-black uppercase tracking-widest disabled:opacity-20 hover:border-indigo-500 transition-all">Previous</button>
                   <div className="flex items-center gap-2">
                     {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                       <button key={p} onClick={() => handlePageChange(p)} className={`w-14 h-14 rounded-2xl text-[11px] font-black transition-all ${p === currentPage ? 'bg-indigo-600 text-white shadow-xl' : 'bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-slate-400 hover:text-indigo-600'}`}>{p}</button>
                     ))}
                   </div>
                   <button onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages} className="px-10 py-5 rounded-[28px] bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-[11px] font-black uppercase tracking-widest disabled:opacity-20 hover:border-indigo-500 transition-all">Next</button>
                 </div>
               )}
            </div>
          )}
        </div>
      </div>

      {feedback && (
         <div className="fixed bottom-16 left-1/2 -translate-x-1/2 bg-slate-900 dark:bg-slate-800 text-white text-[10px] font-black uppercase tracking-[0.4em] py-4 px-10 rounded-full shadow-2xl z-[400] border border-white/5 transition-all duration-300">
            {feedback}
         </div>
      )}
    </div>
  );
};
