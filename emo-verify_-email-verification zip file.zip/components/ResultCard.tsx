import React, { useState } from 'react';
import { VerificationResult, VerificationStatus, RiskLevel } from '../types';
import { ICONS } from '../constants';

interface ResultCardProps {
  result: VerificationResult;
  selected?: boolean;
  onToggle?: (email: string) => void;
  onDelete?: () => void;
  isAllowlisted?: boolean;
  isBlocklisted?: boolean;
}

export const ResultCard: React.FC<ResultCardProps> = ({ 
  result, 
  selected, 
  onToggle,
  onDelete,
  isAllowlisted,
  isBlocklisted
}) => {
  const [showAudit, setShowAudit] = useState(false);

  const getStatusTheme = (status: VerificationStatus) => {
    switch (status) {
      case VerificationStatus.VALID: return { 
        bg: 'bg-emerald-50/50 dark:bg-emerald-500/10', 
        text: 'text-emerald-700 dark:text-emerald-400', 
        border: 'border-emerald-100 dark:border-emerald-900/50', 
        accent: 'bg-emerald-500' 
      };
      case VerificationStatus.INVALID: return { 
        bg: 'bg-rose-50/50 dark:bg-rose-500/10', 
        text: 'text-rose-700 dark:text-rose-400', 
        border: 'border-rose-100 dark:border-rose-900/50', 
        accent: 'bg-rose-500' 
      };
      case VerificationStatus.RISKY: return { 
        bg: 'bg-amber-50/50 dark:bg-amber-500/10', 
        text: 'text-amber-700 dark:text-amber-400', 
        border: 'border-amber-100 dark:border-amber-900/50', 
        accent: 'bg-amber-500' 
      };
    }
  };

  const theme = getStatusTheme(result.status);
  const StatusIcon = result.status === VerificationStatus.VALID ? ICONS.CheckCircle :
                     result.status === VerificationStatus.INVALID ? ICONS.XCircle : ICONS.AlertTriangle;

  const deliverability = Math.max(1, Math.min(100, Math.round(result.deliverabilityScore || 0)));
  const domain = result.domainAnalysis;

  const factors = [
    { label: 'Syntax', value: result.scoreBreakdown.syntax, icon: <ICONS.CheckCircle className="w-3 h-3" /> },
    { label: 'DNS Health', value: result.scoreBreakdown.dns, icon: <ICONS.Shield className="w-3 h-3" /> },
    { label: 'SMTP Logic', value: result.scoreBreakdown.smtp, icon: <ICONS.Logo className="w-3 h-3" /> }
  ];

  return (
    <div className={`group relative bg-white dark:bg-slate-900 rounded-[40px] border transition-all duration-500 overflow-hidden flex flex-col ${selected ? 'border-indigo-400 dark:border-indigo-500 ring-4 ring-indigo-50 dark:ring-indigo-900/20 shadow-2xl' : 'border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl hover:-translate-y-1'}`}>
      {/* Header Status Bar */}
      <div className={`px-8 py-5 flex items-center justify-between border-b ${theme.bg} ${theme.border}`}>
        <div className="flex items-center gap-4">
          <div className="relative flex items-center justify-center">
             <input type="checkbox" checked={selected} onChange={() => onToggle?.(result.email)} className="w-5 h-5 rounded-lg border-slate-300 dark:border-slate-700 text-indigo-600 focus:ring-indigo-500 cursor-pointer transition-all appearance-none border-2 checked:bg-indigo-600 checked:border-indigo-600 dark:checked:bg-indigo-500 dark:checked:border-indigo-500" />
             {selected && <div className="absolute pointer-events-none text-white"><svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="4"><path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round"/></svg></div>}
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2.5">
              <StatusIcon className={`w-4 h-4 ${theme.text}`} />
              <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${theme.text}`}>{result.status}</span>
            </div>
            {result.primaryRiskVector !== 'NONE' && (
              <span className="text-[8px] font-black uppercase text-rose-500 dark:text-rose-400 mt-0.5 tracking-widest">{result.primaryRiskVector.replace('_', ' ')}</span>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <button onClick={onDelete} className="p-2 text-slate-300 dark:text-slate-600 hover:text-rose-600 dark:hover:text-rose-400 transition-colors opacity-0 group-hover:opacity-100" title="Purge Result">
            <ICONS.Trash className="w-4 h-4" />
          </button>
          <div className={`px-4 py-2 rounded-2xl ${theme.bg} ${theme.border} border`}>
            <span className={`text-[14px] font-black ${theme.text}`}>{deliverability}%</span>
            <span className="text-[7px] font-black text-slate-400 uppercase ml-2 tracking-widest">Score</span>
          </div>
        </div>
      </div>
      
      <div className="p-8 flex-grow">
        <div className="mb-8">
          <div className="relative group/mail">
            <div className="text-lg font-mono font-bold text-slate-900 dark:text-white break-all leading-snug bg-slate-50 dark:bg-slate-950 p-5 rounded-[20px] border border-slate-100 dark:border-slate-800 transition-all group-hover/mail:border-indigo-200 dark:group-hover/mail:border-indigo-900 group-hover/mail:bg-white dark:group-hover/mail:bg-slate-900">
              {result.email}
            </div>
            <button 
              className="absolute right-4 top-1/2 -translate-y-1/2 p-2 text-slate-300 dark:text-slate-600 hover:text-indigo-600 dark:hover:text-indigo-400 opacity-0 group-hover/mail:opacity-100 transition-all"
              onClick={() => { navigator.clipboard.writeText(result.email); }}
            >
              <ICONS.Copy className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Deliverability Gauge */}
        <div className="mb-8 p-6 bg-slate-50 dark:bg-slate-950 rounded-[32px] border border-slate-100 dark:border-slate-800">
           <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                 <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                 <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Neural Delivery Matrix</span>
              </div>
              <span className={`text-[10px] font-black uppercase tracking-widest ${theme.text}`}>Forensic Grade</span>
           </div>
           <div className="grid grid-cols-1 gap-y-4">
              {factors.map((f, i) => (
                 <div key={i} className="space-y-2">
                    <div className="flex justify-between items-center">
                       <div className="flex items-center gap-1.5 text-[8px] font-black uppercase text-slate-500 tracking-widest">
                          {f.icon}
                          {f.label}
                       </div>
                       <span className={`text-[9px] font-black ${f.value > 80 ? 'text-emerald-500' : f.value > 50 ? 'text-amber-500' : 'text-rose-500'}`}>
                          {f.value}%
                       </span>
                    </div>
                    <div className="h-1 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                       <div className={`h-full transition-all duration-1000 ${f.value > 80 ? 'bg-emerald-500' : f.value > 50 ? 'bg-amber-500' : 'bg-rose-500'}`} style={{ width: `${f.value}%` }} />
                    </div>
                 </div>
              ))}
           </div>
        </div>

        {/* Network Telemetry - Always Visible */}
        <div className="mb-8">
           <div className="flex items-center gap-3 mb-4 px-1">
              <ICONS.Logo className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span className="text-[9px] font-black uppercase tracking-widest text-indigo-900 dark:text-indigo-300">Network Telemetry</span>
           </div>
           
           <div className="grid grid-cols-2 gap-2">
              <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-xl">
                 <div className="text-[7px] font-black text-slate-400 uppercase mb-1">Provider</div>
                 <div className="text-[10px] font-bold dark:text-white truncate">{domain.providerType} Node</div>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-xl">
                 <div className="text-[7px] font-black text-slate-400 uppercase mb-1">MX Handshake</div>
                 <div className="text-[10px] font-bold dark:text-white">{domain.mxLikelihood} Stability</div>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-xl col-span-2">
                 <div className="text-[7px] font-black text-slate-400 uppercase mb-2 text-center">DNS Protocols</div>
                 <div className="flex justify-around items-center">
                    <div className="flex items-center gap-1.5">
                       <div className={`w-1.5 h-1.5 rounded-full ${domain.dnsRecords.spf === 'Configured' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                       <span className="text-[8px] font-black dark:text-white uppercase">SPF</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                       <div className={`w-1.5 h-1.5 rounded-full ${domain.dnsRecords.dkim === 'Found' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                       <span className="text-[8px] font-black dark:text-white uppercase">DKIM</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                       <div className={`w-1.5 h-1.5 rounded-full ${domain.dnsRecords.dmarc === 'Configured' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                       <span className="text-[8px] font-black dark:text-white uppercase">DMARC</span>
                    </div>
                 </div>
              </div>
           </div>
        </div>

        {/* Audit Log Trigger */}
        <button 
          onClick={() => setShowAudit(!showAudit)} 
          className="w-full py-4 text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 hover:text-indigo-600 transition-all border-t border-slate-50 dark:border-slate-800/50 mt-4"
        >
          {showAudit ? 'Collapse Audit Logs' : 'View Audit Sequence'}
        </button>
        
        {showAudit && (
          <div className="mt-6 space-y-4 animate-in slide-in-from-top-4 fade-in duration-500">
            {result.auditLog.map((log, i) => (
              <div key={i} className="flex gap-4">
                <div className="flex flex-col items-center shrink-0">
                  <div className={`w-2.5 h-2.5 rounded-full ring-4 ring-white dark:ring-slate-900 ${
                    log.status === 'success' ? 'bg-emerald-500' : log.status === 'warning' ? 'bg-amber-500' : 'bg-rose-500'
                  }`} />
                  {i < result.auditLog.length - 1 && <div className="w-0.5 h-full bg-slate-100 dark:bg-slate-800" />}
                </div>
                <div className="pb-4">
                  <div className="text-[8px] font-black uppercase text-slate-400 tracking-widest mb-1">{log.step}</div>
                  <div className="text-[10px] font-bold dark:text-slate-300 leading-tight">{log.result}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};