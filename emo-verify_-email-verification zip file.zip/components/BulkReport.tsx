import React, { useState, useMemo, useEffect } from 'react';
import { ICONS } from '../constants';
import { BulkAudit, VerificationStatus, VerificationResult } from '../types';
import { ResultCard } from './ResultCard';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';

interface BulkReportProps {
  audit: BulkAudit;
  onBack: () => void;
  onLaunchSegmentation?: () => void;
}

export const BulkReport: React.FC<BulkReportProps> = ({ audit, onBack, onLaunchSegmentation }) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<VerificationStatus | 'ALL'>('ALL');
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    if (feedback) {
      const timer = setTimeout(() => setFeedback(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [feedback]);

  const filteredResults = useMemo(() => {
    return audit.results.filter(r => {
      const matchesSearch = r.email.toLowerCase().includes(search.toLowerCase());
      const matchesFilter = filter === 'ALL' || r.status === filter;
      return matchesSearch && matchesFilter;
    });
  }, [audit.results, search, filter]);

  const statsData = [
    { name: 'Valid', value: audit.summary.valid, color: '#10B981' },
    { name: 'Risky', value: audit.summary.risky, color: '#F59E0B' },
    { name: 'Invalid', value: audit.summary.invalid, color: '#EF4444' },
  ];

  const deliveryDistribution = useMemo(() => {
    const buckets = new Array(10).fill(0);
    audit.results.forEach(r => {
      const index = Math.min(Math.floor(r.deliverabilityScore / 10), 9);
      buckets[index]++;
    });
    return buckets.map((count, i) => ({
      range: `${i * 10}-${(i + 1) * 10}%`,
      count
    }));
  }, [audit.results]);

  const filterOptions = ['ALL', 'Valid', 'Risky', 'Invalid'];
  const filterIndex = filterOptions.indexOf(filter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 animate-in fade-in duration-700">
      <div className="mb-12 flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <button onClick={onBack} className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-indigo-600 mb-6 hover:translate-x-1 transition-all">
            <ICONS.ChevronUp className="-rotate-90 w-4 h-4" />
            Back to Archives
          </button>
          <h1 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tighter leading-none mb-2 uppercase">{audit.name}</h1>
          <p className="text-slate-500 dark:text-slate-400 font-bold text-sm tracking-wide uppercase">Forensic Audit Telemetry</p>
        </div>

        <div className="flex flex-wrap items-center gap-4">
           <button 
             onClick={onLaunchSegmentation}
             className="px-8 py-4 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-[0.3em] rounded-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 dark:shadow-none flex items-center gap-3"
           >
             <ICONS.List className="w-4 h-4" />
             Explore Segments
           </button>
           <div className="bg-white dark:bg-slate-900 px-8 py-4 rounded-[28px] border border-slate-100 dark:border-slate-800 shadow-sm">
              <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Avg. Deliverability</div>
              <div className="text-2xl font-black text-indigo-600">{Math.round(audit.summary.avgDeliverability)}%</div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 mb-16">
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-10 rounded-[48px] border border-slate-100 dark:border-slate-800 shadow-xl">
           <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-10">Neural Health Ratio</h3>
           <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={statsData} cx="50%" cy="50%" innerRadius={70} outerRadius={90} paddingAngle={10} dataKey="value" stroke="none">
                    {statsData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: '24px', border: 'none', background: '#0F172A', color: '#fff' }} />
                </PieChart>
              </ResponsiveContainer>
           </div>
           <div className="mt-8 space-y-4">
              {statsData.map(stat => (
                <div key={stat.name} className="flex items-center justify-between">
                   <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full" style={{ background: stat.color }} />
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{stat.name}</span>
                   </div>
                   <span className="text-xs font-black dark:text-white">{stat.value}</span>
                </div>
              ))}
           </div>
        </div>

        <div className="lg:col-span-8 bg-white dark:bg-slate-900 p-10 rounded-[48px] border border-slate-100 dark:border-slate-800 shadow-xl">
           <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-10">Delivery % Distribution</h3>
           <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={deliveryDistribution}>
                  <XAxis dataKey="range" axisLine={false} tickLine={false} tick={{ fontSize: 9, fontWeight: 900, textTransform: 'uppercase' }} />
                  <YAxis hide />
                  <Tooltip cursor={{ fill: 'transparent' }} contentStyle={{ borderRadius: '20px', border: 'none', background: '#0F172A', color: '#fff' }} />
                  <Bar dataKey="count" fill="#4F46E5" radius={[10, 10, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
           </div>
        </div>
      </div>

      <div className="space-y-8">
         <div className="flex flex-col xl:flex-row items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-[32px] border border-slate-100 dark:border-slate-800 shadow-sm">
            <div className="relative flex-grow w-full">
               <ICONS.Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
               <input 
                type="text" 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-12 pr-6 py-3 bg-slate-50 dark:bg-slate-950 rounded-2xl outline-none text-[11px] font-black uppercase tracking-widest dark:text-white border border-transparent focus:border-indigo-500 transition-all" 
                placeholder="Search result nodes..." 
               />
            </div>
            
            <div className="relative bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl flex items-center border border-slate-200/50 dark:border-slate-700/50 overflow-hidden">
               {/* Sliding Pill */}
               <div 
                 className={`absolute top-1 bottom-1 rounded-xl transition-all duration-500 ease-in-out shadow-md ${
                    filter === 'ALL' ? 'bg-indigo-600' :
                    filter === 'Valid' ? 'bg-emerald-600' :
                    filter === 'Risky' ? 'bg-amber-500' :
                    'bg-rose-600'
                 }`}
                 style={{ 
                   width: 'calc(25% - 2px)', 
                   left: `calc(${filterIndex * 25}% + 1px)` 
                 }}
               />
               {filterOptions.map(f => (
                  <button 
                    key={f} 
                    onClick={() => setFilter(f as any)} 
                    className={`relative z-10 px-5 py-2.5 whitespace-nowrap rounded-xl text-[9px] font-black uppercase tracking-widest transition-colors duration-300 w-24 text-center ${
                      filter === f ? 'text-white' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
                    }`}
                  >
                    {f}
                  </button>
               ))}
            </div>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
           {filteredResults.map((res) => (
             <ResultCard key={res.email} result={res} />
           ))}
         </div>
         
         {filteredResults.length === 0 && (
            <div className="py-20 text-center text-slate-400 text-[10px] font-black uppercase tracking-widest">
               No results match your criteria
            </div>
         )}
      </div>

      {feedback && (
         <div className="fixed bottom-12 left-1/2 -translate-x-1/2 bg-slate-900 dark:bg-emerald-600 text-white text-[9px] font-black uppercase tracking-[0.3em] py-3 px-8 rounded-full shadow-2xl z-[600] animate-in slide-in-from-bottom-4 border border-white/10">
            {feedback}
         </div>
      )}
    </div>
  );
};