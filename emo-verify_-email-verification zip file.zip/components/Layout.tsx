
import React, { useState, useEffect } from 'react';
import { ICONS } from '../constants';
import { User } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  user: User | null;
  onLogout: () => void;
  onNavigatePricing: () => void;
  onNavigateDashboard: () => void;
  onNavigateHistory: () => void;
  onNavigateProtocols: () => void;
  onNavigateDocumentation: () => void;
  onNavigateApiKeys: () => void;
  onNavigateTerms: () => void;
  onNavigatePrivacy: () => void;
  currentView: string;
}

export const Layout: React.FC<LayoutProps> = ({ 
  children, 
  user, 
  onLogout, 
  onNavigatePricing, 
  onNavigateDashboard,
  onNavigateHistory,
  onNavigateProtocols,
  onNavigateDocumentation,
  onNavigateApiKeys,
  onNavigateTerms,
  onNavigatePrivacy,
  currentView
}) => {
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('emo_theme');
    return saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('emo_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('emo_theme', 'light');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);

  const usagePercent = user ? Math.min(100, Math.round((user.usageCount / user.usageLimit) * 100)) : 0;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-[#020617] text-slate-900 dark:text-slate-100 transition-colors duration-500 selection:bg-indigo-100 dark:selection:bg-indigo-900 selection:text-indigo-900 dark:selection:text-indigo-100">
      <header className="bg-white/80 dark:bg-slate-900/80 border-b border-slate-200/60 dark:border-slate-800/60 sticky top-0 z-[100] backdrop-blur-xl transition-all duration-500">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          {/* Brand Logo */}
          <button 
            className="flex items-center gap-4 group focus:outline-none rounded-2xl p-1 transition-all" 
            onClick={onNavigateDashboard}
          >
            <div className="bg-indigo-600 p-2.5 rounded-2xl group-hover:rotate-6 group-hover:scale-110 transition-all duration-500 shadow-xl shadow-indigo-200 dark:shadow-indigo-900/40">
              <ICONS.Logo className="w-7 h-7 text-white" />
            </div>
            <div className="flex flex-col text-left">
              <div className="flex items-baseline gap-0.5">
                <span className="text-2xl font-black text-slate-900 dark:text-white tracking-tighter leading-none">EMO</span>
                <span className="text-2xl font-light text-indigo-600 dark:text-indigo-400 tracking-tighter leading-none">VERIFY</span>
              </div>
              <span className="text-[8px] font-black uppercase tracking-[0.3em] text-slate-400 dark:text-slate-500 mt-1">Neural Engine v2.5</span>
            </div>
          </button>
          
          {user && (
            <nav className="flex items-center gap-1 bg-slate-100/50 dark:bg-slate-800/50 p-1.5 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 transition-colors duration-500">
              {[
                { label: 'Console', view: 'dashboard', action: onNavigateDashboard, icon: <ICONS.Search className="w-4 h-4" /> },
                { label: 'Docs', view: 'documentation', action: onNavigateDocumentation, icon: <ICONS.BookOpen className="w-4 h-4" /> },
                { label: 'Upgrade', view: 'pricing', action: onNavigatePricing, icon: <ICONS.CreditCard className="w-4 h-4" /> },
              ].map((link) => (
                <button 
                  key={link.view}
                  onClick={link.action}
                  className={`flex items-center gap-2 px-5 py-2.5 text-[11px] font-black uppercase tracking-widest rounded-xl transition-all duration-300 ${
                    currentView === link.view
                      ? 'text-indigo-600 dark:text-indigo-400 bg-white dark:bg-slate-900 shadow-sm ring-1 ring-slate-200 dark:ring-slate-700' 
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  {link.icon}
                  {link.label}
                </button>
              ))}
            </nav>
          )}

          <div className="flex items-center gap-6">
            <button 
              onClick={toggleDarkMode}
              className="p-3 text-slate-400 dark:text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200/50 dark:border-slate-700/50"
            >
              <div className="relative w-5 h-5">
                <div className={`absolute inset-0 transition-all duration-500 transform ${isDarkMode ? 'rotate-90 scale-0 opacity-0' : 'rotate-0 scale-100 opacity-100'}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.72 9.72 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 0 0 9.002-5.998Z" />
                  </svg>
                </div>
                <div className={`absolute inset-0 transition-all duration-500 transform ${isDarkMode ? 'rotate-0 scale-100 opacity-100' : '-rotate-90 scale-0 opacity-0'}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v2.25m6.364.386-1.591 1.591M21 12h-2.25m-.386 6.364-1.591-1.591M12 18.75V21m-4.773-4.227-1.591 1.591M3 12h2.25m.386-6.364 1.591-1.591M15.75 12a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" />
                  </svg>
                </div>
              </div>
            </button>

            {user && (
              <div className="flex items-center gap-6 pl-6 border-l border-slate-200/80 dark:border-slate-800">
                <div className="flex flex-col items-end">
                  <span className="text-xs font-black text-slate-900 dark:text-white leading-none">{user.name}</span>
                  <div className="flex items-center gap-3 mt-1.5">
                    <div className="flex flex-col items-end gap-0.5">
                       <span className="text-[9px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest leading-none">{user.tier} NODE</span>
                       <div className="w-16 h-1 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                          <div 
                            className={`h-full transition-all duration-500 ${usagePercent > 90 ? 'bg-rose-500' : usagePercent > 70 ? 'bg-amber-500' : 'bg-emerald-500'}`} 
                            style={{ width: `${usagePercent}%` }} 
                          />
                       </div>
                    </div>
                    <div className={`w-1.5 h-1.5 rounded-full ${usagePercent >= 100 ? 'bg-rose-500' : 'bg-emerald-500 animate-pulse'}`}></div>
                  </div>
                </div>
                <button 
                  onClick={onLogout}
                  className="p-3 text-slate-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200/50 dark:border-slate-700/50"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9" />
                  </svg>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>
      
      <main className="flex-grow">
        {children}
      </main>
      
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16 items-center">
            <div className="flex flex-col items-start gap-4">
              <div className="flex items-center gap-3">
                <ICONS.Logo className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                <span className="text-xs font-black tracking-[0.3em] uppercase text-slate-900 dark:text-white">EMO Intelligence</span>
              </div>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium max-w-xs text-left leading-relaxed uppercase tracking-widest">
                Real-time neural deliverability auditing and reputation management for enterprise operations.
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-12 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500">
               <button onClick={onNavigateProtocols} className="hover:text-indigo-600 transition-colors">Safety Protocols</button>
               <button onClick={onNavigateApiKeys} className="hover:text-indigo-600 transition-colors">API Keys</button>
               <button onClick={onNavigateDocumentation} className="hover:text-indigo-600 transition-colors">Documentation</button>
            </div>
            <div className="text-right">
               <div className="text-[10px] font-bold text-slate-300 dark:text-slate-600 uppercase tracking-widest flex flex-col items-end gap-2">
                 <span>System Epoch 2025 &copy; EMO Labs</span>
                 <div className="flex gap-4">
                   <button onClick={onNavigateTerms} className="hover:text-indigo-600 transition-colors text-[9px]">Terms of Service</button>
                   <button onClick={onNavigatePrivacy} className="hover:text-indigo-600 transition-colors text-[9px]">Privacy Policy</button>
                 </div>
               </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
