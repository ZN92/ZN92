
import React, { useState } from 'react';
import { ICONS } from '../constants';
import { User, SubscriptionTier } from '../types';

interface PricingProps {
  user: User | null;
  onUpgrade: (tier: SubscriptionTier) => void;
}

export const Pricing: React.FC<PricingProps> = ({ user, onUpgrade }) => {
  const [processing, setProcessing] = useState<SubscriptionTier | null>(null);

  const tiers = [
    {
      id: SubscriptionTier.FREE,
      name: 'Starter Node',
      price: 0,
      description: 'Foundational verification logic.',
      features: ['100 AUDITS / MO', 'DNS INFRASTRUCTURE SCAN', 'REPUTATION SIGNAL (BASIC)'],
      buttonText: user?.tier === SubscriptionTier.FREE ? 'CURRENT UNIT' : 'SELECT',
      dark: false,
      glow: false
    },
    {
      id: SubscriptionTier.PRO,
      name: 'Pro Engine',
      price: 49,
      description: 'High-throughput neural auditing.',
      features: ['5,000 AUDITS / MO', 'BULK SCAN', 'PROTOCOL EXPORTS', 'PRIORITY NODE SYNC', 'NEURAL FINGERPRINTING'],
      buttonText: user?.tier === SubscriptionTier.PRO ? 'CURRENT UNIT' : 'ACTIVATE ENGINE',
      dark: true,
      glow: true
    },
    {
      id: SubscriptionTier.ENTERPRISE,
      name: 'Omni Bulk',
      price: 199,
      description: 'Unrestricted bulk access.',
      features: ['UNLIMITED AUDITS', 'FULL API INTEGRATION', 'MULTI-TENANT SUPPORT', 'DEDICATED NODE SUPP.'],
      buttonText: user?.tier === SubscriptionTier.ENTERPRISE ? 'CURRENT UNIT' : 'CONTACT COMMAND',
      dark: false,
      glow: false
    }
  ];

  const handleAction = (tierId: SubscriptionTier) => {
    if (user?.tier === tierId) return;
    setProcessing(tierId);
    setTimeout(() => {
      onUpgrade(tierId);
      setProcessing(null);
    }, 1500);
  };

  return (
    <div className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center mb-24">
        <h1 className="text-5xl md:text-6xl font-black text-slate-900 dark:text-white tracking-tighter uppercase leading-none mb-6">Network Tiers</h1>
        <p className="max-w-xl mx-auto text-[11px] font-black uppercase tracking-[0.5em] text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/30 py-3 rounded-full">Neural Resource Allocation</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
        {tiers.map((tier) => (
          <div 
            key={tier.id}
            className={`group relative flex flex-col p-12 rounded-[64px] transition-all duration-700 ${
              tier.dark 
                ? 'bg-slate-900 dark:bg-slate-900 text-white shadow-[0_40px_80px_-15px_rgba(0,0,0,0.3)] border dark:border-slate-800' 
                : 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-2 border-slate-100 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-500 shadow-xl shadow-slate-200/50 dark:shadow-none'
            } ${tier.glow ? 'scale-105 z-10' : 'hover:-translate-y-2'}`}
          >
            {tier.glow && (
              <div className="absolute inset-0 bg-indigo-500/20 blur-[100px] -z-10 animate-pulse"></div>
            )}
            
            {tier.id === SubscriptionTier.PRO && (
              <div className="absolute top-8 right-12 bg-indigo-600 text-white text-[9px] font-black uppercase tracking-[0.3em] px-4 py-1.5 rounded-full shadow-lg shadow-indigo-200 dark:shadow-none">
                Most Deployed
              </div>
            )}

            <div className="mb-12">
              <h3 className={`text-2xl font-black uppercase tracking-tight ${tier.dark ? 'text-white' : 'text-slate-900 dark:text-white'}`}>{tier.name}</h3>
              <p className={`mt-3 text-[10px] font-black uppercase tracking-[0.2em] ${tier.dark ? 'text-slate-500' : 'text-slate-400 dark:text-slate-500'}`}>{tier.description}</p>
              
              <div className="mt-10 flex items-baseline gap-2">
                <span className="text-6xl font-black tracking-tighter">${tier.price}</span>
                <span className={`text-[10px] font-black uppercase tracking-widest ${tier.dark ? 'text-slate-500' : 'text-slate-400 dark:text-slate-500'}`}>/ Node Sync</span>
              </div>
            </div>

            <div className={`h-px w-full mb-12 ${tier.dark ? 'bg-white/5' : 'bg-slate-50 dark:bg-slate-800'}`} />

            <ul className="flex-grow space-y-5 mb-12">
              {tier.features.map((feature, idx) => (
                <li key={idx} className="flex items-center gap-4">
                  <div className={`p-1 rounded-full ${tier.dark ? 'bg-indigo-500 text-white' : 'bg-indigo-50 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400'}`}>
                    <ICONS.CheckCircle className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-[0.2em]">{feature}</span>
                </li>
              ))}
            </ul>

            <button
              onClick={() => handleAction(tier.id)}
              disabled={processing !== null || user?.tier === tier.id}
              className={`group w-full py-6 rounded-[32px] text-[11px] font-black uppercase tracking-[0.4em] transition-all duration-500 relative overflow-hidden ${
                tier.dark 
                  ? 'bg-white dark:bg-indigo-500 text-slate-900 dark:text-white hover:bg-indigo-400 dark:hover:bg-indigo-600' 
                  : 'bg-slate-900 dark:bg-slate-800 text-white hover:bg-indigo-600 dark:hover:bg-indigo-700'
              } disabled:opacity-30 shadow-2xl shadow-indigo-100/10 dark:shadow-none`}
            >
              <span className="relative z-10">
                {processing === tier.id ? 'SYNCING...' : tier.buttonText}
              </span>
              {!tier.dark && <div className="absolute inset-0 bg-indigo-500 translate-y-full group-hover:translate-y-0 transition-transform duration-500 -z-0"></div>}
            </button>
          </div>
        ))}
      </div>
      
      <div className="mt-24 text-center">
         <div className="inline-flex items-center gap-4 bg-white dark:bg-slate-900 px-8 py-4 rounded-[28px] border border-slate-100 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none">
            <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Global Protocol Availability:</span>
            <div className="flex -space-x-2">
               {[1,2,3,4].map(i => (
                 <div key={i} className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 border-2 border-white dark:border-slate-900 flex items-center justify-center">
                    <ICONS.User className="w-3 h-3 text-slate-400 dark:text-slate-600" />
                 </div>
               ))}
            </div>
            <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">+12k Nodes Live</span>
         </div>
      </div>
    </div>
  );
};
