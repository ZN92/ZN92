
import React, { useState, useRef, useMemo } from 'react';
import { ICONS } from '../constants';
import { WorkspaceState } from '../types';
import * as XLSX from 'xlsx';

interface WorkspaceProps {
  workspace: WorkspaceState;
  setWorkspace: React.Dispatch<React.SetStateAction<WorkspaceState>>;
  onBack: () => void;
}

type WorkspaceTab = 'email_allow' | 'email_block';

interface SyncLog {
  id: string;
  email: string;
  status: 'success' | 'duplicate' | 'error';
  reason?: string;
  timestamp: number;
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const Workspace: React.FC<WorkspaceProps> = ({ 
  workspace,
  setWorkspace,
  onBack 
}) => {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('email_allow');
  const [searchTerm, setSearchTerm] = useState('');
  const [bulkInput, setBulkInput] = useState('');
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'warning' | 'error' } | null>(null);
  const [syncLogs, setSyncLogs] = useState<SyncLog[]>([]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getList = () => {
    switch (activeTab) {
      case 'email_allow': return workspace.allowlistedEmails;
      case 'email_block': return workspace.blocklistedEmails;
    }
  };

  const currentList = getList();
  const filteredItems = Array.from(currentList).filter((item: string) => 
    item.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const logStats = useMemo(() => {
    return {
      success: syncLogs.filter(l => l.status === 'success').length,
      duplicate: syncLogs.filter(l => l.status === 'duplicate').length,
      error: syncLogs.filter(l => l.status === 'error').length
    };
  }, [syncLogs]);

  const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const extension = file.name.toLowerCase().split('.').pop();
      let extracted: string[] = [];

      if (['xlsx', 'xls', 'csv'].includes(extension || '')) {
        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json<any>(firstSheet, { header: 1 });
        extracted = rows.flat()
          .map(cell => String(cell).trim())
          .filter(cell => cell.includes('@'));
      } else {
        const text = await file.text();
        extracted = text.split(/[\n, ]+/).map(e => e.trim()).filter(e => e.length > 0);
      }

      setBulkInput(prev => (prev ? prev + '\n' : '') + extracted.join('\n'));
      setFeedback({ message: `INGESTED ${extracted.length} NODES FROM ${extension?.toUpperCase()}`, type: 'success' });
    } catch (err) {
      setFeedback({ message: 'IMPORT_FAULT: COULD NOT PARSE SOURCE', type: 'error' });
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
      setTimeout(() => setFeedback(null), 3000);
    }
  };

  const handleBulkAdd = () => {
    const rawEntries = bulkInput.split(/[\n, ]+/).map(e => e.trim()).filter(e => e.length > 0);
    
    if (rawEntries.length === 0) {
      setFeedback({ message: 'PROTOCOL FAULT: INPUT BUFFER EMPTY', type: 'error' });
      setTimeout(() => setFeedback(null), 3000);
      return;
    }

    const logs: SyncLog[] = [];
    const validToAdd: string[] = [];
    
    const key = activeTab === 'email_allow' ? 'allowlistedEmails' : 'blocklistedEmails';
    const existingSet = workspace[key];

    rawEntries.forEach(entry => {
      const id = Math.random().toString(36).substr(2, 9);
      const timestamp = Date.now();
      if (!EMAIL_REGEX.test(entry)) {
        logs.push({ id, email: entry, status: 'error', reason: 'INVALID_FORMAT', timestamp });
      } else if (existingSet.has(entry)) {
        logs.push({ id, email: entry, status: 'duplicate', reason: 'ALREADY_IN_REGISTRY', timestamp });
      } else if (validToAdd.includes(entry)) {
        logs.push({ id, email: entry, status: 'duplicate', reason: 'BATCH_DUPLICATE', timestamp });
      } else {
        validToAdd.push(entry);
        logs.push({ id, email: entry, status: 'success', timestamp });
      }
    });

    if (validToAdd.length > 0) {
      setWorkspace(prev => {
        const nextSet = new Set(prev[key]);
        validToAdd.forEach(e => nextSet.add(e));
        return { ...prev, [key]: nextSet };
      });
    }

    setBulkInput('');
    setSyncLogs(logs);
    
    const successCount = validToAdd.length;
    if (successCount === rawEntries.length) {
      setFeedback({ message: `TOTAL SYNC SUCCESS: ${successCount} NODES`, type: 'success' });
    } else {
      setFeedback({ 
        message: `SYNC COMPLETED WITH EXCEPTIONS: ${rawEntries.length - successCount} FAULTS`, 
        type: successCount > 0 ? 'warning' : 'error' 
      });
    }
    
    setTimeout(() => setFeedback(null), 5000);
  };

  const removeItem = (item: string) => {
    const key = activeTab === 'email_allow' ? 'allowlistedEmails' : 'blocklistedEmails';
    setWorkspace(prev => {
      const nextSet = new Set(prev[key]);
      nextSet.delete(item);
      return { ...prev, [key]: nextSet };
    });
  };

  return (
    <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-12 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-16 gap-6">
        <div>
          <h2 className="text-4xl font-black text-slate-900 dark:text-white uppercase tracking-tighter leading-none mb-3">System Control</h2>
          <p className="text-[10px] text-slate-400 dark:text-slate-500 font-black uppercase tracking-[0.4em]">Registry Vault Configuration</p>
        </div>
        <button 
          onClick={onBack}
          className="group flex items-center gap-3 px-8 py-4 border-2 border-slate-900 dark:border-slate-100 font-black text-[11px] uppercase tracking-[0.3em] hover:bg-slate-900 dark:hover:bg-slate-100 hover:text-white dark:hover:text-slate-900 transition-all duration-500 rounded-2xl text-slate-900 dark:text-slate-100"
        >
          <ICONS.ChevronUp className="-rotate-90 w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          Exit Terminal
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Control Logic Panel */}
        <div className="lg:col-span-4 space-y-10">
          <div className="bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 p-8 rounded-[40px] shadow-2xl shadow-slate-200/50 dark:shadow-none">
             <h3 className="text-[11px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.4em] mb-8 border-b border-slate-50 dark:border-slate-800 pb-5 flex items-center gap-3">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-600 dark:bg-indigo-400" />
                Rule Logic
             </h3>
             <div className="space-y-3">
                {(['email_allow', 'email_block'] as WorkspaceTab[]).map(tab => (
                  <button 
                    key={tab}
                    onClick={() => {
                      setActiveTab(tab);
                      setSyncLogs([]);
                    }}
                    className={`group w-full flex items-center justify-between p-5 rounded-[24px] border-2 transition-all duration-500 ${activeTab === tab ? 'bg-slate-900 dark:bg-indigo-600 border-slate-900 dark:border-indigo-600 text-white shadow-xl shadow-slate-200 dark:shadow-none' : 'bg-white dark:bg-slate-950 border-slate-50 dark:border-slate-800 text-slate-400 dark:text-slate-500 hover:border-slate-200 dark:hover:border-slate-700 hover:text-slate-900 dark:hover:text-white'}`}
                  >
                    <span className="text-[10px] font-black uppercase tracking-[0.2em]">{tab.replace('_', ' ')}</span>
                    <div className={`px-3 py-1 rounded-full text-[9px] font-black transition-colors ${activeTab === tab ? 'bg-white/20 text-white' : 'bg-slate-50 dark:bg-slate-800 text-slate-400 dark:text-slate-500 group-hover:bg-slate-100 dark:group-hover:bg-slate-700'}`}>
                      {workspace[tab === 'email_allow' ? 'allowlistedEmails' : 'blocklistedEmails'].size}
                    </div>
                  </button>
                ))}
             </div>
          </div>

          <div className="bg-[#0F172A] dark:bg-slate-900 p-10 text-white border-2 border-slate-900 dark:border-slate-800 rounded-[40px] shadow-2xl shadow-indigo-900/10">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-[11px] font-black uppercase tracking-[0.4em] text-slate-500">Registry Input</h3>
              <div className="flex gap-2">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 text-slate-500 hover:text-white transition-colors"
                  title="Import CSV/Excel/Text"
                >
                  <ICONS.Import className="w-4 h-4" />
                </button>
              </div>
              <input type="file" ref={fileInputRef} onChange={handleFileImport} className="hidden" accept=".csv,.txt,.xlsx,.xls" />
            </div>
            <div className="relative group">
              <textarea 
                 value={bulkInput}
                 onChange={(e) => setBulkInput(e.target.value)}
                 placeholder="INITIALIZE_LIST_ONE_PER_LINE..."
                 className="w-full h-48 p-6 text-[11px] font-mono border-2 border-white/10 dark:border-slate-800 rounded-[28px] focus:border-white outline-none transition-all bg-white/5 dark:bg-slate-950 placeholder:text-white/20 custom-scrollbar"
               />
               <div className="absolute top-4 right-4 text-[8px] font-black text-white/10 group-focus-within:text-white/30">TERMINAL_READY</div>
            </div>
             <button 
               onClick={handleBulkAdd}
               disabled={!bulkInput.trim()}
               className="w-full mt-6 py-6 bg-white dark:bg-indigo-600 text-slate-900 dark:text-white font-black uppercase tracking-[0.4em] text-[11px] transition-all hover:bg-indigo-400 dark:hover:bg-indigo-500 hover:text-white disabled:opacity-10 rounded-[28px] shadow-xl shadow-black/20"
             >
               Sync Registry
             </button>

             {syncLogs.length > 0 && (
               <div className="mt-10 space-y-4 animate-in fade-in slide-in-from-top-4">
                  <div className="flex flex-col gap-4 border-b border-white/5 dark:border-slate-800 pb-4">
                    <div className="flex items-center justify-between">
                      <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-[0.3em]">Sync Assessment</h4>
                      <button onClick={() => setSyncLogs([])} className="text-[8px] text-slate-500 hover:text-white uppercase font-black tracking-widest bg-white/5 px-2 py-1 rounded-md transition-all">Clear Logs</button>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-2">
                      <div className="bg-emerald-500/10 border border-emerald-500/20 p-2 rounded-xl text-center">
                        <div className="text-[7px] font-black text-emerald-500 uppercase tracking-widest mb-0.5">Success</div>
                        <div className="text-xs font-black text-emerald-400">{logStats.success}</div>
                      </div>
                      <div className="bg-amber-500/10 border border-amber-500/20 p-2 rounded-xl text-center">
                        <div className="text-[7px] font-black text-amber-500 uppercase tracking-widest mb-0.5">Duplicate</div>
                        <div className="text-xs font-black text-amber-400">{logStats.duplicate}</div>
                      </div>
                      <div className="bg-rose-500/10 border border-rose-500/20 p-2 rounded-xl text-center">
                        <div className="text-[7px] font-black text-rose-500 uppercase tracking-widest mb-0.5">Failed</div>
                        <div className="text-xs font-black text-rose-400">{logStats.error}</div>
                      </div>
                    </div>
                  </div>

                  <div className="max-h-80 overflow-y-auto space-y-2 pr-3 custom-scrollbar">
                    {syncLogs.map((log) => (
                      <div key={log.id} className={`flex items-start justify-between p-4 border rounded-2xl transition-all ${
                        log.status === 'success' ? 'bg-emerald-950/20 border-emerald-900/30 shadow-sm shadow-emerald-500/5' : 
                        log.status === 'duplicate' ? 'bg-amber-950/20 border-amber-900/30' : 'bg-rose-950/20 border-rose-900/30'
                      }`}>
                        <div className="flex flex-col min-w-0 flex-1 mr-4">
                          <span className={`text-[10px] font-mono truncate font-bold ${log.status === 'success' ? 'text-emerald-400' : log.status === 'duplicate' ? 'text-amber-400' : 'text-rose-400'}`}>
                            {log.email}
                          </span>
                          {log.reason && (
                            <div className="flex items-center gap-1.5 mt-1 opacity-80">
                               <div className={`w-1 h-1 rounded-full ${log.status === 'duplicate' ? 'bg-amber-400' : 'bg-rose-400'}`} />
                               <span className="text-[7px] font-black uppercase tracking-widest text-slate-400">{log.reason.replace('_', ' ')}</span>
                            </div>
                          )}
                        </div>
                        <div className={`shrink-0 text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded-lg shadow-sm ${
                          log.status === 'success' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 
                          log.status === 'duplicate' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        }`}>
                          {log.status}
                        </div>
                      </div>
                    ))}
                  </div>
               </div>
             )}
          </div>
        </div>

        {/* Live List Display */}
        <div className="lg:col-span-8">
           <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 overflow-hidden flex flex-col h-[820px] rounded-[48px] shadow-2xl shadow-slate-200/50 dark:shadow-none">
              <div className="px-12 py-10 border-b border-slate-50 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-8">
                 <div className="flex items-center gap-4">
                    <div className="p-4 bg-slate-900 dark:bg-indigo-600 rounded-[20px] shadow-xl shadow-slate-200 dark:shadow-none">
                       <ICONS.List className="w-6 h-6 text-white" />
                    </div>
                    <div>
                       <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-[0.1em]">{activeTab.replace('_', ' ')}</h3>
                       <div className="flex items-center gap-2 mt-1">
                          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                          <p className="text-[9px] text-slate-400 dark:text-slate-500 font-black uppercase tracking-widest">Live Registry Feed</p>
                       </div>
                    </div>
                 </div>
                 
                 <div className="relative w-full sm:w-auto">
                    <input 
                      type="text" 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="SEARCH_REGISTRY..."
                      className="w-full sm:w-72 pl-12 pr-6 py-4 text-[11px] font-black border-2 border-slate-50 dark:border-slate-800 outline-none bg-slate-50 dark:bg-slate-950 focus:bg-white dark:focus:bg-slate-900 focus:border-indigo-600 dark:focus:border-indigo-400 rounded-[20px] transition-all uppercase tracking-[0.2em] text-slate-900 dark:text-white"
                    />
                    <ICONS.Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-slate-600" />
                 </div>
              </div>

              <div className="flex-grow overflow-y-auto p-12 custom-scrollbar">
                 {filteredItems.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                       {filteredItems.map((item: string) => (
                          <div key={item} className="flex items-center justify-between p-5 bg-white dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-[24px] hover:border-indigo-600 dark:hover:border-indigo-50 hover:shadow-xl hover:shadow-indigo-50 dark:hover:shadow-none transition-all group">
                             <span className="text-[11px] font-mono font-bold text-slate-900 dark:text-slate-200 truncate tracking-tight">{item}</span>
                             <button onClick={() => removeItem(item)} className="p-2 opacity-0 group-hover:opacity-100 transition-all text-slate-300 dark:text-slate-600 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-xl">
                                <ICONS.Trash className="w-4 h-4" />
                             </button>
                          </div>
                       ))}
                    </div>
                 ) : (
                    <div className="h-full flex flex-col items-center justify-center opacity-10 dark:opacity-5 py-40">
                       <ICONS.Logo className="w-32 h-32 text-slate-900 dark:text-white" />
                       <span className="text-[12px] font-black uppercase tracking-[0.5em] mt-8 text-slate-900 dark:text-white">Empty Sector</span>
                    </div>
                 )}
              </div>

              {feedback && (
                 <div className={`mx-12 mb-10 py-5 rounded-[24px] text-white text-[10px] font-black uppercase tracking-[0.4em] text-center transition-all duration-500 animate-in slide-in-from-bottom-6 ${
                   feedback.type === 'success' ? 'bg-emerald-600 dark:bg-emerald-600 shadow-2xl shadow-emerald-500/20 dark:shadow-none' : 
                   feedback.type === 'warning' ? 'bg-amber-600 dark:bg-amber-500 shadow-2xl shadow-amber-500/20 dark:shadow-none' : 'bg-rose-700 dark:bg-rose-600'
                 }`}>
                    {feedback.message}
                 </div>
              )}
           </div>
        </div>
      </div>
    </div>
  );
};
