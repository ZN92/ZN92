
import React, { useState } from 'react';
import { ICONS } from '../constants';

interface ContactDPOProps {
  onBack: () => void;
}

export const ContactDPO: React.FC<ContactDPOProps> = ({ onBack }) => {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    type: 'SAR',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate encryption and transmission
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
    }, 2000);
  };

  if (success) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-32 text-center animate-in zoom-in-95 duration-500">
        <div className="w-24 h-24 bg-emerald-100 dark:bg-emerald-900/30 rounded-[32px] flex items-center justify-center mx-auto mb-10 shadow-xl shadow-emerald-100 dark:shadow-none">
          <ICONS.CheckCircle className="w-12 h-12 text-emerald-600 dark:text-emerald-400" />
        </div>
        <h2 className="text-4xl font-black text-slate-900 dark:text-white uppercase tracking-tighter mb-6">Transmission Successful</h2>
        <p className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] leading-relaxed mb-12">
          INQUIRY ENCRYPTED & TRANSMITTED TO COMPLIANCE NODE.<br/>A DPO OFFICER WILL RESPOND WITHIN 72 EPOCHS.
        </p>
        <button 
          onClick={onBack}
          className="px-12 py-5 bg-indigo-600 text-white text-[11px] font-black uppercase tracking-[0.4em] rounded-[24px] hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 dark:shadow-none"
        >
          Return to Privacy
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 animate-in fade-in duration-700">
      <div className="mb-20">
        <button onClick={onBack} className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-indigo-600 mb-10 hover:translate-x-1 transition-all">
          <ICONS.ChevronUp className="-rotate-90 w-4 h-4" />
          Privacy Framework
        </button>
        <h1 className="text-5xl md:text-7xl font-black text-slate-900 dark:text-white tracking-tighter leading-none mb-6 uppercase">Secure Channel</h1>
        <p className="text-slate-500 dark:text-slate-400 font-bold text-sm tracking-wide uppercase">Direct Data Protection Officer Inquiry</p>
      </div>

      <div className="bg-white dark:bg-slate-900 p-8 md:p-16 rounded-[64px] border border-slate-100 dark:border-slate-800 shadow-2xl shadow-slate-200/50 dark:shadow-none">
        <form onSubmit={handleSubmit} className="space-y-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 ml-1">Identity Profile</label>
              <input 
                type="text" 
                required
                className="w-full px-8 py-5 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-[28px] outline-none focus:ring-2 focus:ring-indigo-500/50 font-bold text-sm dark:text-white transition-all"
                placeholder="Full Legal Name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 ml-1">Return Node (Email)</label>
              <input 
                type="email" 
                required
                className="w-full px-8 py-5 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-[28px] outline-none focus:ring-2 focus:ring-indigo-500/50 font-bold text-sm dark:text-white transition-all"
                placeholder="name@organization.com"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 ml-1">Inquiry Protocol</label>
            <select 
              className="w-full px-8 py-5 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-[28px] outline-none focus:ring-2 focus:ring-indigo-500/50 font-bold text-sm dark:text-white transition-all appearance-none cursor-pointer"
              value={formData.type}
              onChange={(e) => setFormData({...formData, type: e.target.value})}
            >
              <option value="SAR">Subject Access Request (SAR)</option>
              <option value="DELETE">Data Erasure Request</option>
              <option value="COMPLIANCE">Legal Compliance Inquiry</option>
              <option value="INCIDENT">Security Incident Report</option>
              <option value="OTHER">General Data Query</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 ml-1">Transmission Payload</label>
            <textarea 
              required
              rows={6}
              className="w-full px-8 py-6 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-[32px] outline-none focus:ring-2 focus:ring-indigo-500/50 font-medium text-sm dark:text-white transition-all resize-none"
              placeholder="Detail your request or report here..."
              value={formData.message}
              onChange={(e) => setFormData({...formData, message: e.target.value})}
            />
          </div>

          <div className="pt-6">
            <button 
              type="submit"
              disabled={loading}
              className="w-full py-6 bg-slate-900 dark:bg-indigo-600 text-white text-[11px] font-black uppercase tracking-[0.5em] rounded-[32px] hover:bg-indigo-700 transition-all shadow-2xl shadow-indigo-200 dark:shadow-none disabled:opacity-50 flex items-center justify-center gap-4"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  Encrypting Payload...
                </>
              ) : (
                'Transmit Request'
              )}
            </button>
            <p className="mt-8 text-[9px] font-mono text-center text-slate-400 dark:text-slate-500 uppercase tracking-widest">
              End-to-End Encrypted Communication Segment
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};
