
import React from 'react';
import { ICONS } from '../constants';

interface ProtocolsProps {
  onBack: () => void;
}

export const Protocols: React.FC<ProtocolsProps> = ({ onBack }) => {
  const protocolPillars = [
    {
      title: 'Neural Sandbox Isolation',
      description: 'All verification logic executes within a temporary, isolated neural container. This prevents data leakage and ensures that sensitive metadata never persists beyond the active session.',
      icon: <ICONS.Shield className="w-8 h-8" />,
      color: 'text-indigo-600'
    },
    {
      title: 'Zero-Persistence Registry',
      description: 'EMO Verify adheres to a strict zero-retention policy for target email addresses. Once an audit is completed or archived locally by the user, the server-side memory pointers are securely purged.',
      icon: <ICONS.Lock className="w-8 h-8" />, // Note: standard SVG Lock if needed
      color: 'text-emerald-600'
    },
    {
      title: 'Non-Intrusive Handshaking',
      description: 'Our proprietary SMTP auditing method performs deep-level deliverability checks without completing a full mail transfer, ensuring zero impact on sender reputation and zero spam trigger risk.',
      icon: <ICONS.CheckCircle className="w-8 h-8" />,
      color: 'text-amber-600'
    },
    {
      title: 'DPA Compliance Standards',
      description: 'Engineered for full alignment with global data protection acts (GDPR, CAN-SPAM, CCPA). We provide the tools for ethical, transparent, and secure list management.',
      icon: <ICONS.Logo className="w-8 h-8" />,
      color: 'text-rose-600'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 animate-in fade-in duration-700">
      <div className="mb-20 flex flex-col items-center text-center">
        <div className="inline-flex items-center gap-3 px-6 py-2 bg-indigo-50 dark:bg-indigo-900/30 rounded-full border border-indigo-100 dark:border-indigo-800 mb-8">
           <div className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
           <span className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-600 dark:text-indigo-400">Security Architecture v2.5</span>
        </div>
        <h1 className="text-5xl md:text-7xl font-black text-slate-900 dark:text-white tracking-tighter leading-none mb-6 uppercase">Safety Protocols</h1>
        <p className="max-w-2xl text-slate-500 dark:text-slate-400 font-bold text-sm tracking-wide uppercase leading-relaxed">
           Deep-tier protection mechanisms designed to safeguard neural intelligence and user data sovereignty.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-20">
         {protocolPillars.map((pillar, idx) => (
           <div key={idx} className="group bg-white dark:bg-slate-900 p-12 rounded-[56px] border border-slate-100 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-500 hover:shadow-2xl transition-all duration-500">
              <div className={`mb-8 p-6 bg-slate-50 dark:bg-slate-950 rounded-3xl inline-block ${pillar.color} shadow-sm group-hover:scale-110 transition-transform`}>
                 {pillar.icon}
              </div>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-4 uppercase tracking-tight">{pillar.title}</h3>
              <p className="text-slate-400 dark:text-slate-500 text-sm font-medium leading-relaxed">
                 {pillar.description}
              </p>
           </div>
         ))}
      </div>

      <div className="bg-slate-900 dark:bg-slate-800 rounded-[64px] p-16 text-center relative overflow-hidden shadow-2xl">
         <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
            {/* Abstract Grid Pattern */}
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <defs><pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1"/></pattern></defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
         </div>
         
         <div className="relative z-10">
            <h2 className="text-3xl font-black text-white mb-8 uppercase tracking-tighter">System Integrity: Nominal</h2>
            <div className="flex flex-wrap justify-center gap-4 mb-12">
               {['End-to-End Encrypted', 'AES-256 Protocol', 'SOC-2 Ready', 'ISO-Neural Certified'].map(badge => (
                 <span key={badge} className="px-6 py-2 bg-white/10 rounded-full text-[10px] font-black uppercase tracking-widest text-white/60 border border-white/5">{badge}</span>
               ))}
            </div>
            <button 
              onClick={onBack}
              className="px-12 py-5 bg-white text-slate-900 text-[11px] font-black uppercase tracking-[0.4em] rounded-[24px] hover:bg-indigo-400 hover:text-white transition-all shadow-xl"
            >
               Return to Console
            </button>
         </div>
      </div>
    </div>
  );
};
