
import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { Auth } from './components/Auth';
import { Pricing } from './components/Pricing';
import { Protocols } from './components/Protocols';
import { Documentation } from './components/Documentation';
import { ApiKeys } from './components/ApiKeys';
import { Terms } from './components/Terms';
import { Privacy } from './components/Privacy';
import { ContactDPO } from './components/ContactDPO';
import { User, SubscriptionTier } from './types';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [view, setView] = useState<'dashboard' | 'pricing' | 'protocols' | 'documentation' | 'apikeys' | 'terms' | 'privacy' | 'contact_dpo'>('dashboard');
  
  useEffect(() => {
    const savedUser = localStorage.getItem('verify_ai_user');
    if (savedUser) setUser(JSON.parse(savedUser));
    setIsLoading(false);
  }, []);

  const handleLogin = (userData: Partial<User>) => {
    const fullUser: User = {
      email: userData.email || '',
      name: userData.name || '',
      tier: SubscriptionTier.FREE,
      usageCount: 0,
      usageLimit: 100,
      ...userData
    };
    setUser(fullUser);
    localStorage.setItem('verify_ai_user', JSON.stringify(fullUser));
  };

  const handleLogout = () => {
    setUser(null);
    setView('dashboard');
    localStorage.removeItem('verify_ai_user');
  };

  const handleUpgrade = (tier: SubscriptionTier) => {
    if (!user) return;
    const limits = {
      [SubscriptionTier.FREE]: 100,
      [SubscriptionTier.PRO]: 5000,
      [SubscriptionTier.ENTERPRISE]: 1000000
    };
    const updatedUser = { ...user, tier, usageLimit: limits[tier] };
    setUser(updatedUser);
    localStorage.setItem('verify_ai_user', JSON.stringify(updatedUser));
    setView('dashboard');
  };

  const updateUsage = (increment: number) => {
    if (!user) return;
    const updatedUser = { ...user, usageCount: user.usageCount + increment };
    setUser(updatedUser);
    localStorage.setItem('verify_ai_user', JSON.stringify(updatedUser));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <Layout 
      user={user} 
      onLogout={handleLogout} 
      onNavigatePricing={() => setView('pricing')}
      onNavigateDashboard={() => setView('dashboard')}
      onNavigateHistory={() => {}} 
      onNavigateProtocols={() => setView('protocols')}
      onNavigateDocumentation={() => setView('documentation')}
      onNavigateApiKeys={() => setView('apikeys')}
      onNavigateTerms={() => setView('terms')}
      onNavigatePrivacy={() => setView('privacy')}
      currentView={view}
    >
      {!user ? (
        <Auth onAuthenticate={handleLogin} />
      ) : view === 'pricing' ? (
        <Pricing user={user} onUpgrade={handleUpgrade} />
      ) : view === 'protocols' ? (
        <Protocols onBack={() => setView('dashboard')} />
      ) : view === 'documentation' ? (
        <Documentation onBack={() => setView('dashboard')} />
      ) : view === 'apikeys' ? (
        <ApiKeys onBack={() => setView('dashboard')} />
      ) : view === 'terms' ? (
        <Terms onBack={() => setView('dashboard')} />
      ) : view === 'privacy' ? (
        <Privacy onBack={() => setView('dashboard')} onNavigateContactDPO={() => setView('contact_dpo')} />
      ) : view === 'contact_dpo' ? (
        <ContactDPO onBack={() => setView('privacy')} />
      ) : (
        <Dashboard user={user} onUpdateUsage={updateUsage} onNavigateUpgrade={() => setView('pricing')} />
      )}
    </Layout>
  );
};

export default App;
