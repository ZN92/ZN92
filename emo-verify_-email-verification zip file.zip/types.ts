
export enum VerificationStatus {
  VALID = 'Valid',
  INVALID = 'Invalid',
  RISKY = 'Risky'
}

export enum RiskLevel {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High'
}

export enum RecommendedAction {
  ACCEPT = 'Accept',
  REVIEW = 'Review',
  BLOCK = 'Block'
}

export enum SubscriptionTier {
  FREE = 'Free',
  PRO = 'Pro',
  ENTERPRISE = 'Enterprise'
}

export interface User {
  email: string;
  name: string;
  avatarUrl?: string;
  tier: SubscriptionTier;
  usageCount: number;
  usageLimit: number;
}

export interface VerificationResult {
  email: string;
  status: VerificationStatus;
  riskLevel: RiskLevel;
  confidenceScore: number;
  deliverabilityScore: number; // Percentage result from 1 to 100
  primaryRiskVector: string;
  scoreBreakdown: {
    syntax: number;
    dns: number;
    smtp: number;
  };
  isDisposable: boolean;
  isRoleBased: boolean;
  isCatchAll: boolean;
  recommendedAction: RecommendedAction;
  syntaxValid: boolean;
  auditLog: {
    step: string;
    result: string;
    status: 'success' | 'warning' | 'error';
  }[];
  domainAnalysis: {
    mxLikelihood: 'High' | 'Low' | 'None';
    typosquattingRisk: boolean;
    providerType: 'Business' | 'Free' | 'Disposable' | 'Educational' | 'Unknown';
    dnsRecords: {
      spf: 'Configured' | 'Missing' | 'Invalid';
      dkim: 'Found' | 'Missing' | 'Probable';
      dmarc: 'Configured' | 'Missing' | 'Relaxed';
      bimi: boolean;
      mtaSts: boolean;
      mxServers: string[];
    };
    smtpCheck: {
      status: 'Responsive' | 'Timeout' | 'Refused' | 'Unknown';
      banner: string;
      supportsTLS: boolean;
      vrfySupported: boolean;
      greylistingDetected: boolean;
    };
  };
}

export interface BulkAudit {
  id: string;
  timestamp: number;
  name: string;
  totalNodes: number;
  results: VerificationResult[];
  summary: {
    valid: number;
    risky: number;
    invalid: number;
    avgDeliverability: number;
  };
}

export interface WorkspaceState {
  allowlistedEmails: Set<string>;
  blocklistedEmails: Set<string>;
}

export interface VerificationHistoryItem {
  timestamp: number;
  results: VerificationResult[];
}